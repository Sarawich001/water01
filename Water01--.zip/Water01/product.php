<?php
session_start();

include 'connection.php';
include 'utils.php';
include 'includes/auth_validate.php';

// กำหนดค่า role จาก SESSION (ถ้าไม่มี ให้ถือว่าเป็น user)
$role = $_SESSION['role'] ?? 'user';

if(isset($_GET['search'])){
    $sql = "SELECT * FROM products 
            WHERE product_name LIKE '%" . $_GET['search'] . "%'";
} else {
    $sql = "SELECT * FROM products";
}

try {
    $products = $con->query($sql);
} catch (Exception $th) {
    echo $th;
}

include('includes/header.php');
?>

<!-- ส่วนหลักของหน้า -->
<div id="page-wrapper">
    <div class="row">
        <div class="col-lg-6">
            <a href="products.php">
                <h1 class="page-header" style="color:black;">สินค้า</h1>
            </a>
        </div>

    </div>
    <?php include 'includes/flash_messages.php' ?>

    <!-- ส่วนค้นหา -->
    <div class="well text-center filter-form ce">
        <form class="form form-inline" style="display:flex" action="">
            <label for="input_search" style="margin-top:5px">ค้นหา</label>
            <input type="text" class="form-control" id="input_search" style="margin-left:5px" name="search"
                placeholder="ชื่อสินค้า" value="<?php echo isset($_GET['search']) ? htmlspecialchars($_GET['search']) : ''; ?>">
            <input type="submit" style="margin-left:5px" value="ค้นหา" class="btn btn-primary">
        </form>
        
    <!-- ปุ่มเพิ่มสินค้าเฉพาะ admin -->
    <?php if($role === 'admin'): ?>
        <div class="mt-3">
            <a href="add_product.php" class="btn btn-success" style="float: right;">
                <h4>+ เพิ่มสินค้า</h4>
            </a>
        </div>
    <?php endif; ?>

    <?php if(isset($_GET['search'])): ?>
        <a class="btn btn-primary mt-2" href="products.php">ย้อนกลับ</a>
    <?php endif; ?>
</div>
    <hr>

    <!-- ตารางแสดงข้อมูลสินค้า -->
    <table class="table table-striped table-bordered table-condensed text-center">
        <thead>
            <tr>
                <th width="10%">รหัสสินค้า</th>
                <th width="15%">หมวดหมู่สินค้า</th>
                <th width="15%">ชื่อสินค้า</th>
                <th width="15%">ราคาสินค้า</th>
                <th width="15%">สต็อกสินค้า</th>
                <th width="15%">การดำเนินการ</th>
            </tr>
        </thead>
        <tbody>
            <?php if($products && $products->num_rows > 0): ?>
                <?php foreach ($products as $product): ?>
                <tr>
                    <td><?php echo htmlspecialchars($product["product_id"]); ?></td>
                    <td><?php echo htmlspecialchars($product["product_category"]); ?></td>
                    <td><?php echo htmlspecialchars($product["product_name"]); ?></td>
                    <td><?php echo number_format($product["product_price"], 2); ?></td>
                    <td><?php echo intval($product["product_stock"]); ?></td>
                    <td>
                        <?php if($role === 'admin'): ?>
                            <a class="btn btn-primary btn-sm" href="edit_product.php?id=<?php echo intval($product["product_id"]); ?>" title="แก้ไข">
                                <i class="fa fa-edit"></i>
                            </a>
                            <a class="btn btn-danger btn-sm" href="utils.php?delete_product=true&id=<?php echo intval($product["product_id"]); ?>" title="ลบ" onclick="return confirm('คุณต้องการลบสินค้ารายนี้หรือไม่?');">
                                <i class="fa fa-trash"></i>
                            </a>
                        <?php else: ?>
                            <button class="btn btn-info btn-sm" disabled>ดูข้อมูล</button>
                        <?php endif; ?>
                    </td>
                </tr>
                <?php endforeach; ?>
            <?php else: ?>
                <tr><td colspan="6">ไม่พบข้อมูลสินค้า</td></tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>

<?php include 'includes/footer.php'; ?>
