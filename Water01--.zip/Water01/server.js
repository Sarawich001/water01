// ไฟล์: server.js
const express = require('express');
const bodyParser = require('body-parser');
const session = require('express-session');
const bcrypt = require('bcrypt');

const app = express();
const PORT = 3000;

// Middleware
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));
app.use(session({
  secret: 'your-secret-key',
  resave: false,
  saveUninitialized: true
}));

// จำลองฐานข้อมูลผู้ใช้ (ในโปรเจคจริงควรใช้ฐานข้อมูลจริง เช่น MongoDB หรือ MySQL)
const users = [
  { 
    id: 1, 
    username: 'viewer1', 
    password: '$2b$10$12345678901234567890123', // รหัสผ่านที่ hash แล้ว
    role: 'viewer' // เปลี่ยน role เป็น viewer
  },
  { 
    id: 2, 
    username: 'admin1', 
    password: '$2b$10$12345678901234567890123', // รหัสผ่านที่ hash แล้ว
    role: 'admin' 
  }
];

// จำลองข้อมูลในระบบ
const data = [
  { id: 1, title: 'ข้อมูลชิ้นที่ 1', content: 'เนื้อหาของข้อมูลชิ้นที่ 1' },
  { id: 2, title: 'ข้อมูลชิ้นที่ 2', content: 'เนื้อหาของข้อมูลชิ้นที่ 2' },
  { id: 3, title: 'ข้อมูลชิ้นที่ 3', content: 'เนื้อหาของข้อมูลชิ้นที่ 3' }
];

// Middleware สำหรับตรวจสอบการเข้าสู่ระบบ
const isAuthenticated = (req, res, next) => {
  if (req.session.user) {
    return next();
  }
  return res.status(401).json({ message: 'กรุณาเข้าสู่ระบบก่อน' });
};

// Middleware สำหรับตรวจสอบสิทธิ์ admin
const isAdmin = (req, res, next) => {
  if (req.session.user && req.session.user.role === 'admin') {
    return next();
  }
  return res.status(403).json({ message: 'คุณไม่มีสิทธิ์เข้าถึงส่วนนี้ (ต้องเป็น admin)' });
};

// Middleware สำหรับตรวจสอบสิทธิ์การแก้ไขข้อมูล (admin เท่านั้น)
const canEditData = (req, res, next) => {
  if (req.session.user && req.session.user.role === 'admin') {
    return next();
  }
  return res.status(403).json({ message: 'คุณมีสิทธิ์แค่ดูข้อมูลเท่านั้น ไม่สามารถแก้ไขได้' });
};

// เส้นทาง (Routes)

// 1. เส้นทางสำหรับการเข้าสู่ระบบ
app.post('/api/login', (req, res) => {
  const { username, password } = req.body;
  
  const user = users.find(u => u.username === username);
  if (!user) {
    return res.status(401).json({ message: 'ชื่อผู้ใช้หรือรหัสผ่านไม่ถูกต้อง' });
  }

  // ในโปรเจคจริงต้องใช้ bcrypt.compare เพื่อเปรียบเทียบรหัสผ่าน
  // ตัวอย่าง: bcrypt.compare(password, user.password, (err, result) => { ... });
  
  // จำลองการเข้าสู่ระบบสำเร็จ
  req.session.user = {
    id: user.id,
    username: user.username,
    role: user.role
  };
  
  return res.json({ 
    message: 'เข้าสู่ระบบสำเร็จ', 
    user: { 
      id: user.id, 
      username: user.username, 
      role: user.role 
    } 
  });
});

// 2. เส้นทางสำหรับการออกจากระบบ
app.post('/api/logout', (req, res) => {
  req.session.destroy();
  res.json({ message: 'ออกจากระบบสำเร็จ' });
});

// 3. API สำหรับดูข้อมูล (ทั้ง viewer และ admin เข้าถึงได้)
app.get('/api/data', isAuthenticated, (req, res) => {
  res.json({ 
    message: 'ข้อมูลทั้งหมดในระบบ',
    data: data,
    userRole: req.session.user.role
  });
});

// 4. API สำหรับดูข้อมูลเฉพาะชิ้น (ทั้ง viewer และ admin เข้าถึงได้)
app.get('/api/data/:id', isAuthenticated, (req, res) => {
  const itemId = parseInt(req.params.id);
  const item = data.find(d => d.id === itemId);
  
  if (!item) {
    return res.status(404).json({ message: 'ไม่พบข้อมูล' });
  }
  
  res.json({ 
    message: 'ข้อมูลที่ค้นหา',
    data: item,
    userRole: req.session.user.role
  });
});

// 5. API สำหรับเพิ่มข้อมูล (admin เท่านั้น)
app.post('/api/data', isAuthenticated, canEditData, (req, res) => {
  const { title, content } = req.body;
  
  if (!title || !content) {
    return res.status(400).json({ message: 'กรุณาระบุ title และ content' });
  }
  
  const newItem = {
    id: data.length + 1,
    title,
    content
  };
  
  data.push(newItem);
  
  res.status(201).json({ 
    message: 'เพิ่มข้อมูลสำเร็จ',
    data: newItem
  });
});

// 6. API สำหรับแก้ไขข้อมูล (admin เท่านั้น)
app.put('/api/data/:id', isAuthenticated, canEditData, (req, res) => {
  const itemId = parseInt(req.params.id);
  const { title, content } = req.body;
  
  const itemIndex = data.findIndex(d => d.id === itemId);
  if (itemIndex === -1) {
    return res.status(404).json({ message: 'ไม่พบข้อมูล' });
  }
  
  if (title) data[itemIndex].title = title;
  if (content) data[itemIndex].content = content;
  
  res.json({ 
    message: 'อัพเดตข้อมูลสำเร็จ',
    data: data[itemIndex]
  });
});

// 7. API สำหรับลบข้อมูล (admin เท่านั้น)
app.delete('/api/data/:id', isAuthenticated, canEditData, (req, res) => {
  const itemId = parseInt(req.params.id);
  
  const itemIndex = data.findIndex(d => d.id === itemId);
  if (itemIndex === -1) {
    return res.status(404).json({ message: 'ไม่พบข้อมูล' });
  }
  
  const deletedItem = data.splice(itemIndex, 1)[0];
  
  res.json({ 
    message: 'ลบข้อมูลสำเร็จ',
    data: deletedItem
  });
});

// 8. API สำหรับดูหน้าแดชบอร์ด (admin เท่านั้น)
app.get('/api/admin/dashboard', isAuthenticated, isAdmin, (req, res) => {
  res.json({ 
    message: 'ยินดีต้อนรับสู่หน้าแดชบอร์ดสำหรับแอดมิน',
    adminInfo: {
      totalUsers: users.length,
      viewerUsers: users.filter(u => u.role === 'viewer').length,
      adminUsers: users.filter(u => u.role === 'admin').length,
      totalDataItems: data.length
    }
  });
});

app.listen(PORT, () => {
  console.log(`เซิร์ฟเวอร์ทำงานที่พอร์ต ${PORT}`);
});