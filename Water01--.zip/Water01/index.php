<?php
session_start();
include 'includes/flash_messages.php';
include_once('includes/header.php');
include 'utils.php';
include 'includes/auth_validate.php';
?>
<div id="page-wrapper" class="container mt-4">
    <?php include 'includes/flash_messages.php'; ?>
    
    <!-- หัวข้อแผงควบคุม -->
    <div class="row mb-4">
        <div class="col-lg-12 d-flex justify-content-between align-items-center">
            <h1 class="page-header">แผงควบคุม</h1>
        </div>
    </div>
    
    <!-- แผงข้อมูล -->
    <div class="row">
        <!-- Panel ผู้ขาย -->
        <div class="col-lg-4 col-md-6 mb-4">
            <div class="card border-primary shadow-sm">
                <div class="card-body text-center">
                    <i class="fa fa-user fa-4x text-primary"></i>
                    <h3 class="mt-3"><?php echo getVendorCount(); ?></h3>
                    <p class="text-muted">ผู้ขาย</p>
                    <a href="vendors.php" class="btn btn-outline-primary btn-sm">ดูรายละเอียด</a>
                </div>
            </div>
        </div>
        
        <!-- Panel ลูกค้า -->
        <div class="col-lg-4 col-md-6 mb-4">
            <div class="card border-success shadow-sm">
                <div class="card-body text-center">
                    <i class="fa fa-group fa-4x text-success"></i>
                    <h3 class="mt-3"><?php echo getCustomerCount(); ?></h3>
                    <p class="text-muted">ลูกค้า</p>
                    <a href="customer.php" class="btn btn-outline-success btn-sm">ดูรายละเอียด</a>
                </div>
            </div>
        </div>
        
        <!-- Panel สินค้า -->
        <div class="col-lg-4 col-md-6 mb-4">
            <div class="card border-warning shadow-sm">
                <div class="card-body text-center">
                    <i class="fa fa-cubes fa-4x text-warning"></i>
                    <h3 class="mt-3"><?php echo getProductCount(); ?></h3>
                    <p class="text-muted">สินค้า</p>
                    <a href="product.php" class="btn btn-outline-warning btn-sm">ดูรายละเอียด</a>
                </div>
            </div>
        </div>
    </div>
    
    <!-- ส่วนแสดงคู่มือการใช้งาน -->
    <div class="row">
        <div class="col-lg-12">
            <div class="d-flex justify-content-between align-items-center mb-3">
                <h2>คู่มือการใช้งาน</h2>
                <a href="upload_manual.php" class="btn btn-primary">
                    <i class="fa fa-upload"></i> อัปโหลดคู่มือการใช้งาน
                </a>
            </div>

            <?php
            // ดึงข้อมูลคู่มือจากตาราง files
            $sql = "SELECT * FROM files ORDER BY uploaded_at DESC";
            $files = $con->query($sql);
            if ($files->num_rows > 0) {
                echo '<ul class="list-group">';
                while ($file = $files->fetch_assoc()) {
                    echo '<li class="list-group-item d-flex justify-content-between align-items-center">';
                    echo '<a href="' . $file['file_path'] . '" target="_blank" class="text-decoration-none">';
                    echo '<i class="fa fa-file-text-o"></i> ' . $file['file_name'];
                    echo '</a>';
                    echo '<span class="badge bg-secondary">' . date("d/m/Y", strtotime($file['uploaded_at'])) . '</span>';
                    echo '</li>';
                }
                echo '</ul>';
            } else {
                echo '<p class="text-muted">ยังไม่มีคู่มือการใช้งาน</p>';
            }
            ?>
        </div>
    </div>
    <!-- /.row -->

</div>
<!-- /#page-wrapper -->

<?php include_once('includes/footer.php'); ?>
