<?php
session_start();

include 'connection.php';
include 'utils.php';
include 'includes/auth_validate.php';

// กำหนดบทบาท (role) จาก SESSION (ถ้าไม่มีให้เป็น 'user')
$role = $_SESSION['role'] ?? 'user';

if (isset($_GET['search'])) {
    $sql = "SELECT vendor.*, products.* 
            FROM vendor 
            JOIN products ON products.product_id = vendor.product_id
            WHERE vendor_name LIKE '%" . $_GET['search'] . "%'
               OR vendor_phone LIKE '%" . $_GET['search'] . "%'";
} else {
    $sql = "SELECT vendor.*, products.* 
            FROM vendor 
            JOIN products ON products.product_id = vendor.product_id";
}

try {
    $vendors = $con->query($sql);
} catch (Exception $th) {
    error_log($sql);
    echo $th;
}

include('includes/header.php');
?>

<div id="page-wrapper">
    <div class="row">
        <div class="col-lg-6">
            <a href="vendors.php">
                <h1 class="page-header" style="color:black;">ผู้ขายสินค้า</h1>
            </a>
        </div>
    </div>
    <?php include 'includes/flash_messages.php'; ?>

    <!-- ส่วนค้นหา -->
    <div class="well text-center filter-form ce">
        <form class="form form-inline" style="display:flex" action="">
            <label for="input_search" style="margin-top:5px">ค้นหา</label>
            <input type="text" class="form-control" id="input_search" style="margin-left:5px" name="search" placeholder="ชื่อ/เบอร์โทร">
            <input type="submit" style="margin-left:5px" value="ค้นหา" class="btn btn-primary">
        </form>

        <?php if(isset($_GET['search'])): ?>
            <a class="btn btn-primary" href="vendors.php">ย้อนกลับ</a>
        <?php endif; ?>

        <!-- แสดงปุ่ม "เพิ่มผู้ขาย" เฉพาะถ้า role == 'admin' -->
        <?php if($role === 'admin'): ?>
            <a href="add_vendor.php" class="btn btn-success" style="float: right; margin-top: 45px; margin-bottom: 20px;">
                <h4>+ เพิ่มผู้ขาย</h4>
            </a>
        <?php endif; ?>
    </div>
    <hr>

    <!-- ตารางแสดงข้อมูล -->
    <table style="text-align:center" class="table table-striped table-bordered table-condensed">
        <thead>
            <tr>
                <th style="text-align:center" width="15%">ชื่อผู้ขาย</th>
                <th style="text-align:center" width="15%">เบอร์โทร</th>
                <th style="text-align:center" width="15%">หมวดหมู่สินค้า</th>
                <th style="text-align:center" width="15%">สินค้า</th>
                <th style="text-align:center" width="10%">จำนวน</th>
                <th style="text-align:center" width="10%">ราคา</th>
                <th style="text-align:center" width="15%">การจัดการ</th>
            </tr>
        </thead>
        <tbody>
            <?php if($vendors): ?>
                <?php foreach ($vendors as $vendor): ?>
                <tr>
                    <td><?php echo htmlspecialchars($vendor["vendor_name"]); ?></td>
                    <td><?php echo htmlspecialchars($vendor["vendor_phone"]); ?></td>
                    <td><?php echo htmlspecialchars($vendor["product_category"]); ?></td>
                    <td><?php echo htmlspecialchars($vendor["product_name"]); ?></td>
                    <td><?php echo intval($vendor["vendor_quantity"]); ?></td>
                    <td><?php echo intval($vendor["vendor_price"]); ?></td>
                    <td>
                        <?php if($role === 'admin'): ?>
                            <!-- Admin: แก้ไข/ลบ/ซื้อ ได้ทั้งหมด -->
                            <a class="btn btn-primary btn-sm" href="edit_vendor.php?id=<?php echo intval($vendor["id"]); ?>" title="แก้ไข">
                                <i class="fa fa-edit"></i>
                            </a>
                            <a class="btn btn-danger btn-sm" href="utils.php?delete_vendor=true&id=<?php echo intval($vendor["id"]); ?>" title="ลบ"
                               onclick="return confirm('คุณต้องการลบผู้ขายรายนี้หรือไม่?');">
                                <i class="fa fa-trash"></i>
                            </a>
                            <a class="btn btn-success btn-sm" href="buy.php?vendors=true&id=<?php echo intval($vendor["id"]); ?>">ซื้อ</a>
                        <?php else: ?>
                            <!-- User: ดูได้อย่างเดียว (ปุ่มแก้ไข/ลบ/ซื้อ ซ่อนไป) -->
                            <button class="btn btn-info btn-sm" disabled>ดูเท่านั้น</button>
                        <?php endif; ?>
                    </td>
                </tr>
                <?php endforeach; ?>
            <?php else: ?>
                <tr><td colspan="7">ไม่พบข้อมูลผู้ขาย</td></tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>

<?php include 'includes/footer.php'; ?>
