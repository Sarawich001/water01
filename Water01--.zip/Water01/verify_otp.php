<?php
session_start();
include 'connection.php';

if (!isset($_SESSION['reset_username'])) {
    echo "ไม่พบข้อมูลผู้ใช้ที่ต้องการเปลี่ยนรหัสผ่าน";
    exit();
}

// ถ้าผู้ใช้กรอก OTP แล้วกดปุ่ม "ยืนยัน"
if (isset($_POST['verify_otp'])) {
    $otp_input = mysqli_real_escape_string($con, $_POST['otp_input']);
    $username = $_SESSION['reset_username'];

    // ตรวจสอบ OTP
    $query = "SELECT reset_otp FROM admin WHERE username='$username'";
    $result = mysqli_query($con, $query);
    $user = mysqli_fetch_assoc($result);

    if ($user && $user['reset_otp'] == $otp_input) {
        // ถ้า OTP ตรงกัน → ไปหน้า reset_password.php
        header("Location: reset_password.php");
        exit();
    } else {
        echo "OTP ไม่ถูกต้อง หรือหมดอายุ";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>ยืนยัน OTP</title>
</head>
<body>
    <h2>ยืนยันรหัส OTP</h2>
    <form method="post">
        <label>OTP 6 หลัก:</label>
        <input type="text" name="otp_input" required>
        <button type="submit" name="verify_otp">ยืนยัน</button>
    </form>
</body>
</html>
