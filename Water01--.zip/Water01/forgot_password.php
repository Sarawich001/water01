<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

// กำหนดโฟลเดอร์ logs
$logFolder = 'C:/xampp/htdocs/Water01/logs';
if (!file_exists($logFolder)) {
    mkdir($logFolder, 0777, true);
}

// ตั้งค่า error log
ini_set('log_errors', 1);
ini_set('error_log', "$logFolder/error.log");

// ฟังก์ชันบันทึก log
function writeLog($message) {
    $logFile = 'C:/xampp/htdocs/Water01/logs/email.log';
    $timestamp = date('Y-m-d H:i:s');
    file_put_contents($logFile, "[$timestamp] $message\n", FILE_APPEND);
}

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require 'C:/xampp/htdocs/Water01/vendor/autoload.php';
include 'C:/xampp/htdocs/Water01/connection.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_POST['email'];
    writeLog("กำลังประมวลผลอีเมล: " . $email);
    
    // ตรวจสอบว่ามีอีเมลในฐานข้อมูลหรือไม่
    $stmt = $conn->prepare("SELECT id FROM admin WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $stmt->store_result();

    if ($stmt->num_rows > 0) {
        $token = bin2hex(random_bytes(32));
        $expiry = date('Y-m-d H:i:s', strtotime('+1 hour'));
        
        $stmt = $conn->prepare("UPDATE admin SET reset_token = ?, reset_expiry = ? WHERE email = ?");
        $stmt->bind_param("sss", $token, $expiry, $email);
        $stmt->execute();
        
        // ส่งอีเมล
        $mail = new PHPMailer(true);
        try {
            $mail->SMTPDebug = 0;
            $mail->isSMTP();
            $mail->Host = 'smtp.gmail.com';
            $mail->SMTPAuth = true;
            $mail->Username = 'koonmu789@gmail.com';
            $mail->Password = 'iafm sbhv dgku zhex';
            $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
            $mail->Port = 587;
            $mail->CharSet = 'UTF-8';
            
            $mail->setFrom('koonmu789@gmail.com', 'Admin Support');
            $mail->addAddress($email);
            
            $reset_link = "http://localhost/Water01/reset_password.php?token=" . $token;
            $mail->isHTML(true);
            $mail->Subject = 'รีเซ็ตรหัสผ่าน';
            $mail->Body = "<h2>รีเซ็ตรหัสผ่าน</h2><p>คลิกที่ลิงค์ด้านล่างเพื่อตั้งรหัสผ่านใหม่:</p><p><a href='$reset_link'>ตั้งรหัสผ่านใหม่</a></p><p>ลิงค์หมดอายุใน 1 ชั่วโมง</p>";
            
            $mail->send();
            writeLog("ส่งอีเมลสำเร็จถึง: $email");
            echo '<div class="alert alert-success">ส่งลิงค์รีเซ็ตรหัสผ่านแล้ว</div>';
        } catch (Exception $e) {
            writeLog("เกิดข้อผิดพลาดในการส่งอีเมล: " . $mail->ErrorInfo);
            echo '<div class="alert alert-danger">ไม่สามารถส่งอีเมลได้</div>';
        }
    } else {
        writeLog("ไม่พบอีเมลในระบบ: $email");
        echo '<div class="alert alert-warning">ไม่พบอีเมลนี้ในระบบ</div>';
    }
}
?>

<!DOCTYPE html>
<html lang="th">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ลืมรหัสผ่าน</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
</head>
<body>
    <div class="container text-center mt-5" style="max-width: 400px;">
        <h2>ลืมรหัสผ่าน</h2>
        <form action="forgot_password.php" method="post">
            <div class="mb-3">
                <label for="email" class="form-label">อีเมล:</label>
                <input type="email" id="email" name="email" class="form-control" required>
            </div>
            <button type="submit" class="btn btn-primary w-100">ส่งลิงค์รีเซ็ตรหัสผ่าน</button>
        </form>
    </div>
</body>
</html>
