<?php
session_start();
include 'config.php'; // ไฟล์เชื่อมต่อฐานข้อมูล
include 'includes/auth_validate.php';

if (isset($_GET['id'])) {
    $file_id = intval($_GET['id']);

    // ค้นหาไฟล์ที่ต้องการลบ
    $sql = "SELECT file_path FROM files WHERE file_id = ?";
    $stmt = $con->prepare($sql);
    $stmt->bind_param("i", $file_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $file = $result->fetch_assoc();

    if ($file) {
        $file_path = $file['file_path'];

        // ลบไฟล์ออกจากเซิร์ฟเวอร์
        if (file_exists($file_path)) {
            unlink($file_path); // ลบไฟล์จริงออกจากโฟลเดอร์
        }

        // ลบข้อมูลไฟล์จากฐานข้อมูล
        $delete_sql = "DELETE FROM files WHERE file_id = ?";
        $delete_stmt = $con->prepare($delete_sql);
        $delete_stmt->bind_param("i", $file_id);

        if ($delete_stmt->execute()) {
            $_SESSION['success'] = "ลบไฟล์สำเร็จ!";
        } else {
            $_SESSION['error'] = "เกิดข้อผิดพลาดในการลบ!";
        }
    } else {
        $_SESSION['error'] = "ไม่พบไฟล์ที่ต้องการลบ!";
    }
} else {
    $_SESSION['error'] = "ไม่มีข้อมูลไฟล์ที่ต้องการลบ!";
}

// กลับไปที่หน้า dashboard
header("Location: dashboard.php");
exit;
?>
