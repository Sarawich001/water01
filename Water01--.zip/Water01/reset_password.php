<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

// สร้างโฟลเดอร์ logs ถ้ายังไม่มี
if (!file_exists('C:/xampp/htdocs/Water01/logs')) {
    mkdir('C:/xampp/htdocs/Water01/logs', 0777, true);
}

// ตั้งค่า error log
ini_set('log_errors', 1);
ini_set('error_log', 'C:/xampp/htdocs/Water01/logs/error.log');

// ฟังก์ชันสำหรับบันทึก log
function writeLog($message) {
    $logFile = 'C:/xampp/htdocs/Water01/logs/email.log';
    $timestamp = date('Y-m-d H:i:s');
    $logMessage = "[$timestamp] $message\n";
    file_put_contents($logFile, $logMessage, FILE_APPEND);
}

// ตรวจสอบว่าไฟล์ connection.php มีอยู่จริง
if (!file_exists('C:/xampp/htdocs/Water01/connection.php')) {
    writeLog("ไม่พบไฟล์ connection.php");
    die("ไม่พบไฟล์ connection.php");
}

$message = '';
$token = isset($_GET['token']) ? $_GET['token'] : '';
$success = false;

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $password = $_POST['password'];
    $confirm_password = $_POST['confirm_password'];
    
    if ($password !== $confirm_password) {
        $message = '<div class="alert alert-danger">รหัสผ่านไม่ตรงกัน</div>';
    } else {
        // เชื่อมต่อกับฐานข้อมูล
        include 'C:/xampp/htdocs/Water01/connection.php';
        
        // ตรวจสอบ token และเวลาหมดอายุ
        $stmt = $conn->prepare("SELECT id FROM admin WHERE reset_token = ? AND reset_expiry > NOW()");
        if (!$stmt) {
            writeLog("เกิดข้อผิดพลาดในการเตรียมคำสั่ง SQL: " . $conn->error);
            $message = '<div class="alert alert-danger">เกิดข้อผิดพลาดในการตรวจสอบ token</div>';
        } else {
            $stmt->bind_param("s", $token);
            $stmt->execute();
            $stmt->store_result();
            
            if ($stmt->num_rows > 0) {
                // อัปเดตรหัสผ่านใหม่
                $hashed_password = password_hash($password, PASSWORD_DEFAULT);
                $stmt = $conn->prepare("UPDATE admin SET password = ?, reset_token = NULL, reset_expiry = NULL WHERE reset_token = ?");
                
                if (!$stmt) {
                    writeLog("เกิดข้อผิดพลาดในการเตรียมคำสั่ง SQL: " . $conn->error);
                    $message = '<div class="alert alert-danger">เกิดข้อผิดพลาดในการอัปเดตรหัสผ่าน</div>';
                } else {
                    $stmt->bind_param("ss", $hashed_password, $token);
                    if ($stmt->execute()) {
                        writeLog("อัปเดตรหัสผ่านสำเร็จ");
                        $message = '<div class="alert alert-success">ตั้งรหัสผ่านใหม่สำเร็จ กรุณาเข้าสู่ระบบด้วยรหัสผ่านใหม่</div>';
                        $success = true;
                    } else {
                        writeLog("เกิดข้อผิดพลาดในการอัปเดตฐานข้อมูล: " . $stmt->error);
                        $message = '<div class="alert alert-danger">เกิดข้อผิดพลาดในการอัปเดตรหัสผ่าน</div>';
                    }
                }
            } else {
                writeLog("Token ไม่ถูกต้องหรือหมดอายุ");
                $message = '<div class="alert alert-danger">ลิงค์รีเซ็ตรหัสผ่านไม่ถูกต้องหรือหมดอายุ กรุณาขอรีเซ็ตรหัสผ่านใหม่</div>';
            }
        }
    }
} else {
    if (empty($token)) {
        $message = '<div class="alert alert-danger">ไม่พบลิงค์รีเซ็ตรหัสผ่าน</div>';
    }
}
?>

<!DOCTYPE html>
<html lang="th">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ตั้งรหัสผ่านใหม่</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <style>
        body {
            background-color: #f8f9fa;
        }
        .container {
            max-width: 400px;
            margin-top: 100px;
            padding: 20px;
            background: #fff;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        .btn-custom {
            background-color: #007bff;
            color: #fff;
        }
    </style>
</head>
<body>
    <div class="container text-center">
        <h2 class="mb-4">ตั้งรหัสผ่านใหม่</h2>
        <?php echo $message; ?>
        
        <?php if (!$success && !empty($token)): ?>
        <form action="reset_password.php?token=<?php echo htmlspecialchars($token); ?>" method="post">
            <div class="mb-3">
                <label for="password" class="form-label">รหัสผ่านใหม่:</label>
                <input type="password" id="password" name="password" class="form-control" required>
            </div>
            <div class="mb-3">
                <label for="confirm_password" class="form-label">ยืนยันรหัสผ่านใหม่:</label>
                <input type="password" id="confirm_password" name="confirm_password" class="form-control" required>
            </div>
            <button type="submit" class="btn btn-custom w-100">ตั้งรหัสผ่านใหม่</button>
        </form>
        <?php endif; ?>
        
        <?php if ($success): ?>
        <div class="mt-3">
            <a href="login.php" class="btn btn-custom">เข้าสู่ระบบ</a>
        </div>
        <?php endif; ?>
    </div>
</body>
</html>
