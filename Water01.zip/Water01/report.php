<?php
session_start();
include 'connection.php';
error_reporting(E_ALL);
ini_set('display_errors', 1);

// กำหนดช่วงเวลาสำหรับรายงาน (ค่าเริ่มต้นเป็นเดือนปัจจุบัน)
$start_date = isset($_GET['start_date']) ? $_GET['start_date'] : date('Y-m-01');
$end_date = isset($_GET['end_date']) ? $_GET['end_date'] : date('Y-m-t');

// ดึงข้อมูลรายงานยอดขาย (ใช้ JOIN กับตาราง customer เพื่อดึง customer_name)
$sql = "SELECT o.order_id, c.customer_name, o.total, o.date 
        FROM orders o
        LEFT JOIN customer c ON o.customer_id = c.customer_id
        WHERE o.date BETWEEN '$start_date' AND '$end_date'
        ORDER BY o.date DESC";
$result = $con->query($sql);

// ดึงสถิติเชิงปริมาณ
$stats_sql = "SELECT 
                COUNT(order_id) AS total_orders,
                SUM(total) AS total_revenue, 
                AVG(total) AS avg_sale,
                MAX(total) AS max_sale,
                MIN(total) AS min_sale
              FROM orders 
              WHERE date BETWEEN '$start_date' AND '$end_date'";
$stats_result = $con->query($stats_sql);
$stats = $stats_result->fetch_assoc();
$total_orders = $stats['total_orders'] ?? 0;
$total_revenue = $stats['total_revenue'] ?? 0;
$avg_sale = $stats['avg_sale'] ?? 0;
$max_sale = $stats['max_sale'] ?? 0;
$min_sale = $stats['min_sale'] ?? 0;

// ดึงข้อมูลยอดขายรายวัน สำหรับกราฟเส้น
$daily_sql = "SELECT DATE(date) AS sale_date, SUM(total) AS daily_total
              FROM orders
              WHERE date BETWEEN '$start_date' AND '$end_date'
              GROUP BY DATE(date)
              ORDER BY sale_date";
$daily_result = $con->query($daily_sql);
$dates = [];
$daily_totals = [];
while ($row = $daily_result->fetch_assoc()) {
    $dates[] = date('d/m/Y', strtotime($row['sale_date']));
    $daily_totals[] = $row['daily_total'];
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>รายงานยอดขายน้ำ</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            margin: 0;
            padding: 20px;
            background-color: #f7f9fc;
        }
        .container {
            max-width: 1200px;
            margin: 0 auto;
            background-color: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        h1 {
            color: #2c3e50;
            text-align: center;
            margin-bottom: 20px;
        }
        .date-form {
            display: flex;
            justify-content: center;
            align-items: center;
            margin-bottom: 30px;
            flex-wrap: wrap;
            gap: 10px;
        }
        .date-form input[type="date"] {
            padding: 8px;
            border: 1px solid #ddd;
            border-radius: 4px;
        }
        .date-form button {
            padding: 8px 15px;
            background-color: #3498db;
            color: white;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }
        .date-form button:hover {
            background-color: #2980b9;
        }
        .summary-box {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 15px;
            margin-bottom: 30px;
        }
        .stat-card {
            background-color: #f1f8ff;
            padding: 15px;
            border-radius: 6px;
            text-align: center;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.05);
        }
        .stat-card h3 {
            margin-top: 0;
            color: #3498db;
        }
        .chart-container {
            margin-bottom: 30px;
            height: 300px;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        th, td {
            padding: 12px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }
        th {
            background-color: #f2f2f2;
            color: #333;
        }
        tr:hover {
            background-color: #f5f5f5;
        }
        @media (max-width: 768px) {
            .summary-box {
                grid-template-columns: 1fr;
            }
            table {
                font-size: 14px;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>รายงานยอดขายน้ำ</h1>
        <form method="GET" class="date-form">
            <label>เลือกช่วงเวลา: </label>
            <input type="date" name="start_date" value="<?php echo $start_date; ?>">
            <input type="date" name="end_date" value="<?php echo $end_date; ?>">
            <button type="submit">ดูรายงาน</button>
        </form>
        
        <div class="summary-box">
            <div class="stat-card">
                <h3>ยอดขายรวม</h3>
                <p><?php echo number_format($total_revenue, 2); ?> บาท</p>
            </div>
            <div class="stat-card">
                <h3>จำนวนคำสั่งซื้อ</h3>
                <p><?php echo number_format($total_orders); ?> รายการ</p>
            </div>
            <div class="stat-card">
                <h3>ยอดขายเฉลี่ย</h3>
                <p><?php echo number_format($avg_sale, 2); ?> บาท</p>
            </div>
            <div class="stat-card">
                <h3>ยอดขายสูงสุด</h3>
                <p><?php echo number_format($max_sale, 2); ?> บาท</p>
            </div>
            <div class="stat-card">
                <h3>ยอดขายต่ำสุด</h3>
                <p><?php echo number_format($min_sale, 2); ?> บาท</p>
            </div>
        </div>
        
        <div class="chart-container">
            <canvas id="salesLineChart"></canvas>
        </div>
        
        <h2>รายละเอียดคำสั่งซื้อ</h2>
        <table>
            <thead>
                <tr>
                    <th>รหัสคำสั่งซื้อ</th>
                    <th>ลูกค้า</th>
                    <th>ยอดรวม</th>
                    <th>วันที่</th>
                </tr>
            </thead>
            <tbody>
                <?php 
                if ($result->num_rows > 0) {
                    while ($row = $result->fetch_assoc()): 
                ?>
                    <tr>
                        <td><?php echo $row['order_id']; ?></td>
                        <td><?php echo $row['customer_name'] ?? 'ไม่ระบุ'; ?></td>
                        <td><?php echo number_format($row['total'], 2); ?> บาท</td>
                        <td><?php echo date('d/m/Y', strtotime($row['date'])); ?></td>
                    </tr>
                <?php 
                    endwhile; 
                } else {
                    echo '<tr><td colspan="4" style="text-align: center;">ไม่พบข้อมูลในช่วงเวลาที่เลือก</td></tr>';
                }
                ?>
            </tbody>
        </table>
    </div>

    <script>
        // กราฟเส้นแสดงยอดขายรายวัน
        var ctxLine = document.getElementById('salesLineChart').getContext('2d');
        var salesLineChart = new Chart(ctxLine, {
            type: 'line',
            data: {
                labels: <?php echo json_encode($dates); ?>,
                datasets: [{
                    label: 'ยอดขายรายวัน (บาท)',
                    data: <?php echo json_encode($daily_totals); ?>,
                    backgroundColor: 'rgba(54, 162, 235, 0.2)',
                    borderColor: 'rgba(54, 162, 235, 1)',
                    borderWidth: 2,
                    pointBackgroundColor: 'rgba(54, 162, 235, 1)',
                    pointRadius: 4,
                    tension: 0.1
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    title: {
                        display: true,
                        text: 'แนวโน้มยอดขายรายวัน',
                        font: { size: 16 }
                    },
                    legend: {
                        position: 'bottom'
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        title: {
                            display: true,
                            text: 'ยอดขาย (บาท)'
                        }
                    },
                    x: {
                        title: {
                            display: true,
                            text: 'วันที่'
                        }
                    }
                }
            }
        });
    </script>
</body>
</html>