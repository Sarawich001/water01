<?php 
   print_r($_SERVER);
   echo "<br>";
  echo $_SERVER['SERVER_NAME'];
echo "<br>";
    echo $_SERVER['REQUEST_URI']

?>