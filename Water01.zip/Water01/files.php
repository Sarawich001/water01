<?php
include 'connection.php';
$sql = "SELECT * FROM files";
$files = $con->query($sql);
?>

<table>
    <tr>
        <th>ชื่อไฟล์</th>
        <th>ดูไฟล์</th>
        <th>ลบ</th>
    </tr>
    <?php while ($file = $files->fetch_assoc()) { ?>
    <tr>
        <td><?= $file['file_name'] ?></td>
        <td><a href="<?= $file['file_path'] ?>" target="_blank">เปิดไฟล์</a></td>
        <td><a href="delete_file.php?id=<?= $file['file_id'] ?>" onclick="return confirm('ลบไฟล์นี้?');">ลบ</a></td>
    </tr>
    <?php } ?>
</table>
