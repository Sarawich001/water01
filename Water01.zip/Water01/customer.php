<?php
session_start();

include 'connection.php';
include 'utils.php';
include 'includes/auth_validate.php';

// กำหนดบทบาทของผู้ใช้ (ถ้าไม่มีใน Session ให้ถือว่าเป็น 'user')
$role = $_SESSION['role'] ?? 'user';

if(isset($_GET['search'])){
$sql = "Select * from customer 
        WHERE customer_name LIKE \"%" .$_GET['search'] ."%\" 
        OR customer_phone LIKE \"%".$_GET['search']."%\"";
}
else{
$sql = "Select * from customer";
}
try {
    $customers = $con->query($sql);
} catch (Exception $th) {
    echo $th;
}

include('includes/header.php');
?>

<!-- Main container -->
<div id="page-wrapper">
    <div class="row">
        <div class="col-lg-6">
            <a href="customers.php">
                <h1 class="page-header " style="color:black;">ลูกค้า</h1>
            </a>
        </div>

    </div>
    <?php include 'includes/flash_messages.php'?>

    <!-- Filters -->
    <div class="well text-center filter-form ce">

        < <form class="form form-inline" style="display:flex" action="">
            <label for=" input_search" style="margin-top:5px">ค้นหา</label>
            <input type="text" class="form-control" id="input_search" style="margin-left:5px" name="search"
                placeholder="ชื่อ/เบอร์โทร" value="<?php if(isset($_GET['search_str'])) echo $search_data?>">

            <input type="submit" style="margin-left:5px" value=" ค้นหา" class="btn btn-primary">
            </form>

            <!-- ปุ่มเพิ่มลูกค้า เฉพาะ Admin -->
        <?php if($role === 'admin'): ?>
            <a href="add_customer.php" class="btn btn-success mt-2" style="float: right;">
                <h4>+ เพิ่มลูกค้า</h4>
            </a>
        <?php endif; ?>
    </div>
    <hr>
    <!-- ตารางแสดงข้อมูลลูกค้า -->
    <table class="table table-striped table-bordered table-condensed text-center">
        <thead>
            <tr>
                <th width="15%">ชื่อลูกค้า</th>
                <th width="15%">เบอร์โทร</th>
                <th width="15%">การดำเนินการ</th>
            </tr>
        </thead>
        <tbody>
            <?php if($customers && $customers->num_rows > 0): ?>
                <?php foreach ($customers as $customer): ?>
                <tr>
                    <td><?php echo htmlspecialchars($customer["customer_name"]); ?></td>
                    <td><?php echo htmlspecialchars($customer["customer_phone"]); ?></td>
                    <td>
                        <?php if($role === 'admin'): ?>
                            <a class="btn btn-primary btn-sm rounded-0" href="edit_customer.php?id=<?php echo intval($customer["customer_id"]); ?>" title="แก้ไข">
                                <i class="fa fa-edit"></i>
                            </a>
                            <a class="btn btn-danger btn-sm rounded-0" href="utils.php?delete_customer=true&id=<?php echo intval($customer["customer_id"]); ?>" title="ลบ" onclick="return confirm('คุณต้องการลบลูกค้ารายนี้หรือไม่?');">
                                <i class="fa fa-trash"></i>
                            </a>
                            <a class="btn btn-warning btn-sm" href="sell.php?id=<?php echo intval($customer["customer_id"]); ?>" title="ขาย">
                                <i class="fa fa-shopping-cart"></i> ขาย
                            </a>
                        <?php else: ?>
                            <button class="btn btn-info btn-sm" disabled>ดูข้อมูล</button>
                        <?php endif; ?>
                    </td>
                </tr>
                <?php endforeach; ?>
            <?php else: ?>
                <tr><td colspan="3">ไม่พบข้อมูลลูกค้า</td></tr>
            <?php endif; ?>
        </tbody>
    </table>
    
    <!-- ส่วนแบ่งหน้า (ถ้ามี) -->
    <div class="text-center">
        <?php
        // $pagination->labels('ก่อนหน้า', 'ถัดไป');
        // echo $pagination->render();
        ?>
    </div>
</div>
<!-- //Main container -->

<?php include 'includes/footer.php'; ?>