<?php
error_reporting(E_ALL & ~E_NOTICE & ~E_USER_NOTICE);

  if(!isset($_SESSION)) 
    { 
        session_start(); 
    } 
include 'connection.php';
function alert_box($msg)
{
  echo "<script>alert(\"".$msg."\")</script>";

}
function redirect($url){
    // echo "<script>window.location.href='".$url."';</script>";
    echo '<script type="text/javascript">
           window.location = "'.$url.'"
      </script>';
    // exit;
}

function getUserProfile($user_id) {
    global $con;
    $stmt = $con->prepare("SELECT * FROM users WHERE id=?");
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    return $stmt->get_result()->fetch_assoc();
}

function updateUserProfile($user_id, $full_name, $phone, $profile_picture) {
    global $con;
    if ($profile_picture) {
        $stmt = $con->prepare("UPDATE users SET full_name=?, phone=?, profile_picture=? WHERE id=?");
        $stmt->bind_param("sssi", $full_name, $phone, $profile_picture, $user_id);
    } else {
        $stmt = $con->prepare("UPDATE users SET full_name=?, phone=? WHERE id=?");
        $stmt->bind_param("ssi", $full_name, $phone, $user_id);
    }
    return $stmt->execute();
}

function updateUserPassword($user_id, $hashed_password) {
    global $con;
    $stmt = $con->prepare("UPDATE users SET password=? WHERE id=?");
    $stmt->bind_param("si", $hashed_password, $user_id);
    return $stmt->execute();
}

function deleteUserAccount($user_id) {
    global $con;
    $stmt = $con->prepare("DELETE FROM users WHERE id=?");
    $stmt->bind_param("i", $user_id);
    return $stmt->execute();
}


function getVendorCount() {
    include "connection.php";
    $sql = "SELECT * FROM vendor";
    $vendors = $con->query($sql);
    $rows= mysqli_num_rows($vendors);
    return $rows;
}
function getCustomerCount() {
    include "connection.php";
    $sql2 = "SELECT * FROM customer";
    $customer2 = $con->query($sql2);
    $rows2= mysqli_num_rows($customer2);
    return $rows2;
}function getProductCount() {
    include "connection.php";
    $sql3 = "SELECT * FROM products";
    $product3 = $con->query($sql3);
    $rows3= mysqli_num_rows($product3);
    return $rows3;
}
function Register(string $username1, string $pasword, string $email){
    include 'connection.php';
    $pasword = password_hash($pasword, PASSWORD_DEFAULT);

    try {    
        // ระบุชื่อคอลัมน์ชัดเจน
        $sql = "INSERT INTO admin (username, email, password, type, reset_otp) VALUES (?, ?, ?, 'admin', NULL)";
        $stmt = $con->prepare($sql);
        $stmt->bind_param("sss", $username1, $email, $pasword); 
        $result = $stmt->execute();
        
        if($result) {
            $_SESSION['success'] = "Registered Success";
            header('Location: login.php');
            exit();
        } else {
            $_SESSION['failure'] = "Registration Failed";
        }
    }
    catch(mysqli_sql_exception $err) {
        $_SESSION['failure'] = "Registration Error: " . mysqli_error($con);
    } finally {
        // เพิ่มวงเล็บเพื่อเรียกใช้เมธอด
        $stmt->close();
        $con->close();
    }
}

function deleteCustomer($customer_id, $conn) {
    // ลบ orders ที่อ้างถึง customer
    $conn->query("DELETE FROM orders WHERE customer_id = $customer_id");
    // ลบ customer
    $conn->query("DELETE FROM customer WHERE customer_id = $customer_id");
}

function deleteProduct($product_id, $conn) {
    // ลบ orders_product ที่อ้างถึง product
    $conn->query("DELETE FROM orders_product WHERE product_id = $product_id");
    // ลบ product
    $conn->query("DELETE FROM products WHERE product_id = $product_id");
}


function Login(string $username1, string $password1) {
    include 'connection.php';

    try {    
        $sql = "SELECT * FROM admin WHERE username = ?";
        $stmt = mysqli_prepare($con, $sql);
        mysqli_stmt_bind_param($stmt, "s", $username1);
        mysqli_stmt_execute($stmt);
        $result = mysqli_stmt_get_result($stmt);

        if (!$result) {
            error_log(mysqli_error($con));
            return "dberror";
        }

        // เช็คว่าพบ username หรือไม่
        if (mysqli_num_rows($result) > 0) {
            $row = mysqli_fetch_assoc($result);
            
            // ตรวจสอบรหัสผ่าน
            if (password_verify($password1, $row['password'])) {
                // เก็บข้อมูลใน SESSION รวมถึง role ด้วย
                $_SESSION['user_id'] = $row['id'];
                $_SESSION['username'] = $row['username'];
                $_SESSION['email'] = $row['email'];
                $_SESSION['role'] = $row['role'];  // เพิ่มบรรทัดนี้เพื่อเก็บ role ของผู้ใช้
                $_SESSION['success'] = "Login successful";

                return "logedin";
            } else {
                return "wrongpass"; // รหัสผ่านผิด
            }
        } else {
            return "nouser"; // ไม่พบ username ในระบบ
        }
    } catch (mysqli_sql_exception $err) {
        error_log(mysqli_error($con));
        return "dberror"; // เกิดข้อผิดพลาดในฐานข้อมูล
    }
}


?>

<?php
if (isset($_GET['delete_id'])) {
    $product_id = $_GET['delete_id'];
    
    // ลบความสัมพันธ์ orders_product ก่อน
    $sql1 = "DELETE FROM orders_product WHERE product_id = ?";
    $stmt1 = $conn->prepare($sql1);
    $stmt1->bind_param("i", $product_id);
    $stmt1->execute();
    
    // ลบสินค้า
    $sql2 = "DELETE FROM products WHERE product_id = ?";
    $stmt2 = $conn->prepare($sql2);
    $stmt2->bind_param("i", $product_id);
    $stmt2->execute();

    if ($stmt2->affected_rows > 0) {
        echo "<script>alert('ลบสินค้าสำเร็จ'); window.location.href='product.php';</script>";
    } else {
        echo "<script>alert('ไม่สามารถลบสินค้าได้');</script>";
    }
}
if (isset($_GET['delete_product']) && isset($_GET['id'])) {
    require_once 'connection.php';
    $product_id = $_GET['id'];

    // ลบจาก orders_product ก่อน
    $sql1 = "DELETE FROM orders_product WHERE product_id = ?";
    $stmt1 = $con->prepare($sql1);
    $stmt1->bind_param("i", $product_id);
    $stmt1->execute();
    $stmt1->close();

    // ลบจาก products
    $sql2 = "DELETE FROM products WHERE product_id = ?";
    $stmt2 = $con->prepare($sql2);
    $stmt2->bind_param("i", $product_id);
    $stmt2->execute();

    if ($stmt2->affected_rows > 0) {
        echo "<script>alert('ลบสินค้าสำเร็จ'); window.location.href='product.php';</script>";
    } else {
        echo "<script>alert('ไม่สามารถลบสินค้าได้ หรือไม่มีสินค้าในระบบ');</script>";
    }

    $stmt2->close();
    $con->close();
    exit();
}

if (isset($_GET['delete_product']) && isset($_GET['id'])) {
    require_once 'connection.php'; 
    $product_id = $_GET['id'];

    // Debug ก่อนลบ
    echo "Trying to delete product ID: " . $product_id;
    exit();
}



if (isset($_GET['delete_vendor'])) {
    $sql = "DELETE FROM vendor WHERE id= " . $_GET['id'];
    $con->query($sql);
    $con->close();
    $_SESSION['success'] = "ลบผู้ขายเรียบร้อยแล้ว";
    redirect('vendors.php');
}

if (isset($_GET['delete_customer'])) {
    $sql = "DELETE FROM customer WHERE customer_id= " . $_GET['id'];
    $con->query($sql);
    $con->close();
    $_SESSION['success'] = "ลบลูกค้าเรียบร้อยแล้ว";
    redirect('customer.php');
}

if (isset($_GET['payment_status'])) {
    $con->query('UPDATE orders SET payment_status="' . $_GET['payment_status'] . '" WHERE order_id = ' . $_GET['order_id']);
    $con->close();
    $_SESSION['success'] = "อัปเดตสถานะการชำระเงินเรียบร้อยแล้ว";
    redirect('orders.php');
}

if (isset($_GET['delete_order'])) {
    $con->query("DELETE FROM `orders_product` WHERE order_id = " . $_GET['id']);
    $con->query("DELETE FROM orders WHERE order_id = " . $_GET['id']);
    $con->close();
    $_SESSION['success'] = "ลบคำสั่งซื้อเรียบร้อยแล้ว";
    redirect('orders.php');
}
?>
