<?php
session_start();
 
include('connection.php');
include('utils.php');
include 'includes/auth_validate.php';

try {
    if(isset($_GET['sell'])) {
        // Validate inputs
        if(!isset($_GET['product_id']) || !isset($_GET['product_quantity']) || 
           !isset($_GET['id']) || !isset($_GET['payment_status2'])) {
            throw new Exception("Missing required parameters");
        }
        
        $product_id = $_GET['product_id']; 
        $product_quantity = $_GET['product_quantity'];
        $customer_id = intval($_GET['id']);
        $payment_status = $_GET['payment_status2'];
        
        // Validate payment status
        if($payment_status !== 'pending' && $payment_status !== 'paid') {
            throw new Exception("Invalid payment status");
        }
        
        // Get the orders table structure
        $table_info = $con->query("DESCRIBE orders");
        $columns = [];
        while($col = $table_info->fetch_assoc()) {
            $columns[] = $col['Field'];
        }
        
        // Build insert SQL based on actual table structure
        if(count($columns) === 7) {
            // First option: 7 columns (order_id, customer_id, vendor_id, payment_id, total, payment_status, date)
            $sql = "INSERT INTO orders VALUES (NULL, ?, NULL, NULL, 0, ?, CURRENT_TIMESTAMP)";
        } else {
            // If different structure or number of columns
            $sql = "INSERT INTO orders (order_id, customer_id, payment_status, date, total) 
                    VALUES (NULL, ?, ?, CURRENT_TIMESTAMP, 0)";
        }
        
        $stmt = $con->prepare($sql);
        $stmt->bind_param("is", $customer_id, $payment_status);
        $stmt->execute();

        // Get the last order id 
        $last_id = $con->insert_id;
        $total = 0;
        
        $flag = 0;
        for($i = 0; $i < count($product_quantity); $i++) { 
            if(isset($product_quantity[$i]) && $product_quantity[$i] !== "" && 
               isset($product_id[$i]) && is_numeric($product_id[$i]) && 
               is_numeric($product_quantity[$i]) && $product_quantity[$i] > 0) {
                
                // Securely get product price
                $price_stmt = $con->prepare("SELECT product_price, product_stock FROM products WHERE product_id = ?");
                $price_stmt->bind_param("i", $product_id[$i]);
                $price_stmt->execute();
                $price_result = $price_stmt->get_result();
                $product_data = $price_result->fetch_assoc();
                
                if(!$product_data) {
                    throw new Exception("Product not found");
                }
                
                $product_price = $product_data['product_price'];
                $current_stock = $product_data['product_stock'];
                
                // Check if enough stock is available
                if($current_stock < $product_quantity[$i]) {
                    throw new Exception("Not enough stock for product ID: " . $product_id[$i]);
                }
                
                $subtotal = (int)$product_price * (int)$product_quantity[$i];
                $total += $subtotal;
                
                // Insert into orders_product
                $order_product_stmt = $con->prepare("INSERT INTO orders_product VALUES (NULL, ?, ?, ?)");
                $order_product_stmt->bind_param("iii", $last_id, $product_id[$i], $product_quantity[$i]);
                $order_product_stmt->execute();
                
                // Update product stock securely
                $update_stock_stmt = $con->prepare("UPDATE products SET product_stock = product_stock - ? WHERE product_id = ?");
                $update_stock_stmt->bind_param("ii", $product_quantity[$i], $product_id[$i]);
                $update_stock_stmt->execute();
                
                $flag++;
            }
        }
        
        if($flag === 0) {
            throw new Exception("No valid products selected");
        }
        
        // Update total in orders table
        $update_total_stmt = $con->prepare("UPDATE orders SET total = ? WHERE order_id = ?");
        $update_total_stmt->bind_param("di", $total, $last_id);
        $update_total_stmt->execute();
        
        redirect("bill.php?order_id=" . $last_id);
    }
}
catch(Exception $e) {
    alert_box($e->getMessage());
}
catch(mysqli_sql_exception $err) {
    if(mysqli_errno($con) == 4025) {
        alert_box("สินค้าหมดสต็อก");  // Out of stock
    } else {
        alert_box(mysqli_error($con));
        alert_box(mysqli_errno($con));
    }
}

// Securely fetch customer information
if(isset($_GET['id']) && is_numeric($_GET['id'])) {
    $customer_id = intval($_GET['id']);
    $stmt = $con->prepare("SELECT * FROM customer WHERE customer_id = ?");
    $stmt->bind_param("i", $customer_id);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if($result->num_rows === 0) {
        alert_box("Customer not found");
        redirect("customers.php");
        exit;
    }
} else {
    alert_box("Invalid customer ID");
    redirect("customers.php");
    exit;
}

// Securely fetch products
$products_stmt = $con->prepare("SELECT * FROM products");
$products_stmt->execute();
$result2 = $products_stmt->get_result();

include_once('includes/header.php'); 
?>

<section id="page-wrapper">
    <?php include 'includes/flash_messages.php'?>
    <div class="container">
        <h2>ขายสินค้า</h2>
        <hr>
        <form class="form" method="GET" action="sell.php">
            <?php if($row = $result->fetch_assoc()) { ?>
            <div class="form-group">
                <label class="control-label col-sm-2" for="email">ชื่อลูกค้า:</label>
                <?php echo htmlspecialchars($row['customer_name']); ?>
            </div>
            <div class="form-group" style="margin-bottom:0;">
                <label class="control-label col-sm-2" for="pwd">เบอร์ติดต่อ :</label>
                <?php echo htmlspecialchars($row['customer_phone']); ?>
            </div>
            <div class="form-group">
                <br><label class="control-label col-sm-2" for="pwd">สถานะการชำระเงิน :</label>
                <input class="form-check-input" type="radio" name="payment_status2" value="pending"
                    id="flexRadioDefault2" checked>
                รอดำเนินการ
                <input class="form-check-input" type="radio" name="payment_status2" value="paid" id="flexRadioDefault2">
                ชำระเงินแล้ว
            </div>

            <div class="form-group">
                <label class="control-label col-sm-2"> เลือกสินค้า :</label>
                <div class="container">
                    <table class="table">
                        <thead>
                            <tr>
                                <th>#</th>
                                <th scope="col">สินค้า</th>
                                <th scope="col">ราคา</th>
                                <th scope="col">จำนวนในสต็อก</th>
                                <th scope="col">จำนวนที่ต้องการ</th>
                            </tr>
                        </thead>

                        <tbody>
                            <?php while($row2 = $result2->fetch_assoc()) { ?>
                            <tr>
                                <td>
                                    <div class="input-group-text">
                                        <input type="checkbox" name="product_id[]" value="<?php echo intval($row2['product_id']); ?>"
                                            aria-label="Checkbox for following text input">
                                    </div>
                                </td>
                                <td><?php echo htmlspecialchars($row2['product_name']) . " -- " . htmlspecialchars($row2['product_category']); ?></td>
                                <td><?php echo htmlspecialchars($row2['product_price']); ?></td>
                                <td><?php echo htmlspecialchars($row2['product_stock']); ?></td>
                                <td><input type="text" name="product_quantity[]" pattern="[0-9]*"></td>
                            </tr>
                            <?php } ?>
                        </tbody>
                    </table>
                </div>
            </div>
            <div class="form-group">
                <input type="hidden" name="id" value="<?php echo intval($row['customer_id']); ?>">
                <div class="col-sm-offset-2 col-sm-10">
                    <button type="submit" class="btn btn-default" name="sell" value="add_customer">ยืนยันการขาย</button>
                </div>
            </div>
            <?php } else { ?>
                <div class="alert alert-danger">Customer not found</div>
            <?php } ?>
        </form>
    </div>
</section>

<?php include 'includes/footer.php'; ?>