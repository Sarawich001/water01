<?php
session_start();
include('connection.php');
include('utils.php');

// Process purchase
if(isset($_GET['buy'])){
    try {
        // Input validation
        if (!isset($_GET['id']) || !isset($_GET['vendor_quantity']) || !isset($_GET['product_id']) ||
            !is_numeric($_GET['id']) || !is_numeric($_GET['vendor_quantity']) || !is_numeric($_GET['product_id'])) {
            alert_box("Invalid input parameters");
            redirect("vendors.php");
            exit;
        }
        
        $vendor_id = intval($_GET['id']);
        $vendor_quantity = intval($_GET['vendor_quantity']);
        $product_id = intval($_GET['product_id']);
        
        // Use prepared statements to update product stock
        $sql1 = "UPDATE `products` SET `product_stock` = `product_stock` + ? WHERE `product_id` = ?";
        $stmt1 = $con->prepare($sql1);
        $stmt1->bind_param("ii", $vendor_quantity, $product_id);
        $stmt1->execute();
        
        // Get the actual structure of the orders table
        $structure_query = "SHOW COLUMNS FROM orders";
        $structure_result = $con->query($structure_query);
        $columns = [];
        
        if ($structure_result) {
            while ($row = $structure_result->fetch_assoc()) {
                $columns[] = $row['Field'];
            }
        } else {
            // Fallback - use only the columns we're confident exist based on original code
            // This was: INSERT INTO orders VALUES (NULL, 0, ?, NULL, 0, 'pending', CURRENT_TIMESTAMP)
            $sql = "INSERT INTO orders (order_id, customer_id, vendor_id, total_amount, payment_status, date) 
                    VALUES (NULL, 0, ?, 0, 'pending', CURRENT_TIMESTAMP)";
            $stmt = $con->prepare($sql);
            $stmt->bind_param("i", $vendor_id);
            $stmt->execute();
        }
        
        $_SESSION['success'] = "Purchase completed successfully";
        redirect("vendors.php");
    }
    catch(mysqli_sql_exception $err){
        if(mysqli_errno($con) === 1062){
            alert_box("Phone no. exists");
        } else {
            alert_box(mysqli_error($con));
        }
    } 
}

// Fetch vendor details for the current view - using prepared statements
if (isset($_GET['id']) && is_numeric($_GET['id'])) {
    $vendor_id = intval($_GET['id']);
    
    $sql = "SELECT vendor.*, products.* 
            FROM vendor JOIN products 
            ON vendor.product_id = products.product_id 
            WHERE vendor.id = ?";
    
    $stmt = $con->prepare($sql);
    $stmt->bind_param("i", $vendor_id);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows === 0) {
        alert_box("Vendor not found");
        redirect("vendors.php");
        exit;
    }
} else {
    alert_box("Invalid vendor ID");
    redirect("vendors.php");
    exit;
}

include_once('includes/header.php'); 
?>

<section id="page-wrapper">
    <div class="container">
        <h2>Confirm Purchase</h2>
        <hr>
        <form class="form" method="GET" action="buy.php">
            <?php 
            if ($row = $result->fetch_assoc()) {
                // Sanitize output
                $vendor_name = htmlspecialchars($row['vendor_name']);
                $vendor_phone = htmlspecialchars($row['vendor_phone']);
                $product_category = htmlspecialchars($row['product_category']);
                $product_name = htmlspecialchars($row['product_name']);
                $vendor_quantity = htmlspecialchars($row['vendor_quantity']);
                $vendor_price = htmlspecialchars($row['vendor_price']);
            ?>
            <div class="form-group">
                <label class="control-label col-sm-2" for="email">ชื่อผู้ขาย:</label>
                <div class="col-sm-10">
                    <label style="font-weight:normal;"><?php echo $vendor_name; ?></label>
                </div>
            </div>
            <div class="form-group">
                <label class="control-label col-sm-2" for="pwd">
                ติดต่อ:</label>
                <div class="col-sm-10">
                    <label style="font-weight:normal;"><?php echo $vendor_phone; ?></label>
                </div>
            </div>
            <div class="form-group">
                <label class="control-label col-sm-2" for="email">หมวดหมู่สินค้า:</label>
                <div class="col-sm-10">
                    <label style="font-weight:normal;"><?php echo $product_category; ?></label>
                </div>
            </div>
            <div class="form-group">
                <label class="control-label col-sm-2" for="pwd">ผลิตภัณฑ์:</label>
                <div class="col-sm-10">
                    <label style="font-weight:normal;"><?php echo $product_name; ?></label>
                </div>
            </div>
            <div class="form-group">
                <label class="control-label col-sm-2" for="pwd">ปริมาณ:</label>
                <div class="col-sm-10">
                    <label style="font-weight:normal;"><?php echo $vendor_quantity; ?></label>
                </div>
            </div>
            <div class="form-group">
                <label class="control-label col-sm-2" for="pwd">ราคา:</label>
                <div class="col-sm-10">
                    <label style="font-weight:normal;"><?php echo $vendor_price; ?></label>
                </div>
            </div>
            <div class="form-group">
                <input type="hidden" name="id" value="<?php echo intval($row['id']); ?>">
                <input type="hidden" name="vendor_quantity" value="<?php echo intval($row['vendor_quantity']); ?>">
                <input type="hidden" name="product_id" value="<?php echo intval($row['product_id']); ?>">
                <div class="col-sm-offset-2 col-sm-10">
                    <button type="submit" class="btn btn-success" name="buy" value="buy">ยืนยันการซื้อ</button>
                </div>
            </div>
            <?php } else { ?>
                <div class="alert alert-danger">ไม่พบข้อมูลผู้ขาย</div>
            <?php } ?>
        </form>
    </div>
</section>

<?php include 'includes/footer.php'; ?>