<?php
session_start();
include 'connection.php';
include 'utils.php';
include 'includes/auth_validate.php';

$Server_url = $_SERVER['SERVER_NAME']."/bill.php?order_id=";
$msg = "สวัสดี! คำสั่งซื้อของคุณได้รับการบันทึกแล้ว \nกรุณาตรวจสอบใบเสร็จได้ที่ลิงก์นี้ \n".$Server_url;

// ตรวจสอบว่าผู้ใช้ล็อกอินอยู่หรือไม่
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php"); // ถ้ายังไม่ล็อกอินให้ไปหน้า login
    exit();
}

$user_role = $_SESSION['role']; 

// ค้นหาตามคำค้นหา
$whereCondition = "1=1"; // แสดงคำสั่งซื้อทั้งหมด

if (isset($_GET['search'])) {
    $search = $_GET['search'];
    $whereCondition .= " AND (orders.order_id LIKE '%$search%' OR customer.customer_name LIKE '%$search%')";
}

// SQL Query
$sql = "SELECT
    orders.order_id AS order_id,
    customer.customer_name AS customer_name,
    customer.customer_phone AS customer_phone,
    orders.payment_status AS payment_status,
    customer.customer_id AS customer_id,
    orders.date AS date,
    orders.total
FROM
    orders
JOIN customer ON orders.customer_id = customer.customer_id
JOIN orders_product ON orders_product.order_id = orders.order_id
JOIN products ON products.product_id = orders_product.product_id
WHERE $whereCondition
GROUP BY orders.order_id
ORDER BY orders.order_id DESC";

try {
    $customers = $con->query($sql);
} catch (Exception $th) {
    echo $th;
}

include('includes/header.php');
?>

<!-- ส่วนแสดงผล -->
<div id="page-wrapper">
    <div class="row">
        <div class="col-lg-6">
            <a href="customers.php">
                <h1 class="page-header" style="color:black;">รายการคำสั่งซื้อ</h1>
            </a>
        </div>
    </div>

    <?php include 'includes/flash_messages.php' ?>

    <!-- ส่วนค้นหา -->
    <div class="well text-center filter-form ce">
        <form class="form form-inline" style="display:flex" action="">
            <label for="input_search" style="margin-top:5px">ค้นหา</label>
            <input type="text" class="form-control" style="margin-left:5px" id="input_search" name="search"
                placeholder="ชื่อ/หมายเลขคำสั่งซื้อ" value="<?php if(isset($_GET['search'])) echo $_GET['search']?>">

            <input type="submit" style="margin-left:5px" value="ค้นหา" class="btn btn-primary">
        </form>
        <?php if(isset($_GET['search'])){ ?>
        <a class="btn btn-primary" href="orders.php">ย้อนกลับ</a>
        <?php } ?>
    </div>
    <hr>

    <!-- ตารางแสดงข้อมูล -->
    <table style="text-align:center" class="table table-striped table-bordered table-condensed">
        <thead>
            <tr>
                <th width="6%">หมายเลขคำสั่งซื้อ</th>
                <th width="15%">ชื่อลูกค้า</th>
                <th width="15%">สถานะการชำระเงิน</th>
                <th width="15%">วันที่</th>
                <th width="15%">ยอดรวม</th>
                <th width="15%">การดำเนินการ</th>
            </tr>
        </thead>
        <tbody>
            <?php 
            if ($customers->num_rows > 0) {
                foreach ($customers as $customer): 
            ?>
            <tr>
                <td><?php echo $customer["order_id"]?></td>
                <td><?php echo $customer["customer_name"]?></td>
                <td>
                    <?php 
                        if($customer['payment_status'] == "paid"){ 
                            echo '<span class="badge badge-success" style="background-color:green">ชำระเงินแล้ว</span>'; 
                        } else {
                            echo '<span class="badge badge-primary" style="background-color:#ffc107">รอดำเนินการ</span>';
                        }
                    ?>
                </td>
                <td><?php echo date('d/m/Y', strtotime($customer["date"]))?></td>
                <td><?php echo number_format($customer["total"], 2); ?> ฿</td>
                <td>
                    <a class="btn btn-warning" href="bill.php?order_id=<?php echo($customer["order_id"]) ?>">ใบเสร็จ</a>

                    <?php if ($user_role == 'admin') { // ปุ่มลบเฉพาะ admin ?>
                    <a class="btn btn-danger btn-sm rounded-0" type="button" data-toggle="tooltip" data-placement="top"
                        href="utils.php?delete_order=true&id=<?php echo $customer["order_id"] ?>" title="ลบ"
                        onclick="return confirm('คุณต้องการลบรายการนี้ใช่หรือไม่?');">
                        <i class="fa fa-trash"></i>
                    </a>
                    <?php } ?>
                </td>
            </tr>
            <?php 
                endforeach; 
            } else {
            ?>
            <tr>
                <td colspan="6">ไม่พบข้อมูลรายการคำสั่งซื้อ</td>
            </tr>
            <?php } ?>
        </tbody>
    </table>

</div>
<!-- // ส่วนแสดงผล -->

<?php include 'includes/footer.php'; ?>
