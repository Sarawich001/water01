<?php
session_start();
include 'connection.php';

if (isset($_POST['username']) && isset($_POST['otp']) && isset($_POST['new_password'])) {
    $username = $_POST['username'];
    $otp = $_POST['otp'];
    $new_password = password_hash($_POST['new_password'], PASSWORD_BCRYPT); // Hash รหัสผ่านใหม่

    // ตรวจสอบ OTP
    $stmt = $con->prepare("SELECT * FROM otp_requests WHERE username = ? AND otp_code = ? AND expires_at > NOW() AND used = 0");
    $stmt->bind_param("ss", $username, $otp);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($row = $result->fetch_assoc()) {
        // อัปเดตรหัสผ่านใหม่
        $stmt = $con->prepare("UPDATE users SET password = ? WHERE username = ?");
        $stmt->bind_param("ss", $new_password, $username);
        $stmt->execute();

        // ทำให้ OTP ใช้ไปแล้ว
        $stmt = $con->prepare("UPDATE otp_requests SET used = 1 WHERE id = ?");
        $stmt->bind_param("i", $row['id']);
        $stmt->execute();

        echo "เปลี่ยนรหัสผ่านสำเร็จ!";
    } else {
        echo "OTP ไม่ถูกต้องหรือหมดอายุ";
    }
}
?>
