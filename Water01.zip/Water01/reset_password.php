<?php
session_start();
include 'connection.php';

if (!isset($_SESSION['reset_username'])) {
    echo "ไม่พบข้อมูลผู้ใช้ที่ต้องการเปลี่ยนรหัสผ่าน";
    exit();
}

// ถ้าผู้ใช้กรอก password ใหม่
if (isset($_POST['reset_pass'])) {
    $new_password = mysqli_real_escape_string($con, $_POST['new_password']);
    $confirm_password = mysqli_real_escape_string($con, $_POST['confirm_password']);
    $username = $_SESSION['reset_username'];

    if ($new_password !== $confirm_password) {
        echo "รหัสผ่านทั้งสองไม่ตรงกัน";
    } else {
        // เข้ารหัสรหัสผ่านด้วย password_hash
        $hashed_password = password_hash($new_password, PASSWORD_BCRYPT);

        // อัปเดตรหัสผ่านใหม่
        $update = "UPDATE admin SET password='$hashed_password', reset_otp=NULL WHERE username='$username'";
        mysqli_query($con, $update);

        // ลบ SESSION
        unset($_SESSION['reset_username']);

        echo "เปลี่ยนรหัสผ่านสำเร็จ! <a href='login.php'>ไปหน้าเข้าสู่ระบบ</a>";
        exit();
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>ตั้งรหัสผ่านใหม่</title>
</head>
<body>
    <h2>ตั้งรหัสผ่านใหม่</h2>
    <form method="post">
        <label>รหัสผ่านใหม่:</label>
        <input type="password" name="new_password" required><br>
        <label>ยืนยันรหัสผ่าน:</label>
        <input type="password" name="confirm_password" required><br>
        <button type="submit" name="reset_pass">เปลี่ยนรหัสผ่าน</button>
    </form>
</body>
</html>
