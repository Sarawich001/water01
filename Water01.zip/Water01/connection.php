<?php
// ตรวจสอบว่า session ถูกเปิดใช้งานแล้วหรือยัง
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

error_reporting(0);

$servername = "127.0.0.1";
$username = "root";
$password = "";
$dbname = "water01";

// Create connection
$con = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($con->connect_error) {
    die("เชื่อมต่อฐานข้อมูลล้มเหลว: " . $con->connect_error);
} else {
    
}

?>
