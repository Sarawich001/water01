<?php
session_start();
require_once('connection.php');
require_once('utils.php');
require_once('includes/auth_validate.php');

// ตรวจสอบว่าถูกส่งมาด้วย POST หรือไม่ และมีการกดปุ่ม add_product หรือไม่
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_product'])) {
    $errors = [];

    // รับค่าจากฟอร์ม พร้อมกรองข้อมูล
    $product_category = trim(filter_input(INPUT_POST, 'product_category', FILTER_SANITIZE_STRING));
    $product_name = trim(filter_input(INPUT_POST, 'product_name', FILTER_SANITIZE_STRING));
    $product_price = filter_input(INPUT_POST, 'product_price', FILTER_VALIDATE_FLOAT);
    $product_stock = filter_input(INPUT_POST, 'product_stock', FILTER_VALIDATE_INT);

    // ตรวจสอบความถูกต้องของข้อมูล
    if (empty($product_category)) {
        $errors[] = "กรุณากรอกหมวดหมู่สินค้า";
    }
    if (empty($product_name)) {
        $errors[] = "กรุณากรอกชื่อสินค้า";
    }
    if ($product_price === false || $product_price < 0) {
        $errors[] = "กรุณากรอกราคาสินค้าให้ถูกต้อง";
    }
    if ($product_stock === false || $product_stock < 0) {
        $errors[] = "กรุณากรอกจำนวนสต๊อกสินค้าให้ถูกต้อง";
    }

    // ถ้าไม่มีข้อผิดพลาด ให้ทำการ INSERT
    if (empty($errors)) {
        try {
            $sql = "INSERT INTO products (product_category, product_name, product_price, product_stock) 
                    VALUES (?, ?, ?, ?)";
            $stmt = $con->prepare($sql);
            $stmt->bind_param("ssdi",
                $product_category,
                $product_name,
                $product_price,
                $product_stock
            );

            if ($stmt->execute()) {
                $_SESSION['success'] = "เพิ่มสินค้าสำเร็จ";
                header("Location: product.php"); // กลับไปหน้า products.php
                exit();
            } else {
                $errors[] = "ไม่สามารถเพิ่มสินค้าได้";
            }
        } catch (mysqli_sql_exception $err) {
            $errors[] = "เกิดข้อผิดพลาดกับฐานข้อมูล: " . htmlspecialchars($err->getMessage());
        } finally {
            if (isset($stmt)) {
                $stmt->close();
            }
            if (isset($con)) {
                $con->close();
            }
        }
    }
}

require_once('includes/header.php'); 
?>

<div class="container mt-4">
    <h2>เพิ่มรายละเอียดสินค้า</h2>
    <hr>

    <?php if (!empty($errors)): ?>
        <div class="alert alert-danger">
            <ul>
                <?php foreach ($errors as $error): ?>
                    <li><?php echo htmlspecialchars($error); ?></li>
                <?php endforeach; ?>
            </ul>
        </div>
    <?php endif; ?>

    <!-- ฟอร์มบันทึกสินค้า -->
    <form method="POST" action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>" class="needs-validation" novalidate>
        <div class="form-group row mb-3">
            <label class="col-sm-2 col-form-label">หมวดหมู่สินค้า:</label>
            <div class="col-sm-10">
                <input type="text" class="form-control w-40" name="product_category" 
                       value="<?php echo htmlspecialchars($product_category ?? ''); ?>"
                       required>
                <div class="invalid-feedback">กรุณากรอกหมวดหมู่สินค้า</div>
            </div>
        </div>

        <div class="form-group row mb-3">
            <label class="col-sm-2 col-form-label">ชื่อสินค้า:</label>
            <div class="col-sm-10">
                <input type="text" class="form-control w-40" name="product_name"
                       value="<?php echo htmlspecialchars($product_name ?? ''); ?>"
                       required>
                <div class="invalid-feedback">กรุณากรอกชื่อสินค้า</div>
            </div>
        </div>

        <div class="form-group row mb-3">
            <label class="col-sm-2 col-form-label">ราคาสินค้า:</label>
            <div class="col-sm-10">
                <input type="number" class="form-control w-40" name="product_price" 
                       value="<?php echo htmlspecialchars($product_price ?? ''); ?>"
                       min="0" step="0.01" required>
                <div class="invalid-feedback">กรุณากรอกราคาสินค้า</div>
            </div>
        </div>

        <div class="form-group row mb-3">
            <label class="col-sm-2 col-form-label">สต๊อกสินค้า:</label>
            <div class="col-sm-10">
                <input type="number" class="form-control w-40" name="product_stock"
                       value="<?php echo htmlspecialchars($product_stock ?? ''); ?>"
                       min="0" required>
                <div class="invalid-feedback">กรุณากรอกจำนวนสต๊อกสินค้า</div>
            </div>
        </div>

        <div class="form-group row">
            <div class="col-sm-10 offset-sm-2">
                <button type="submit" class="btn btn-primary" name="add_product" value="1">บันทึก</button>
            </div>
        </div>
    </form>
</div>

<script>
// Bootstrap form validation
(function() {
    'use strict';
    window.addEventListener('load', function() {
        var forms = document.getElementsByClassName('needs-validation');
        var validation = Array.prototype.filter.call(forms, function(form) {
            form.addEventListener('submit', function(event) {
                if (form.checkValidity() === false) {
                    event.preventDefault();
                    event.stopPropagation();
                }
                form.classList.add('was-validated');
            }, false);
        });
    }, false);
})();
</script>

<?php require_once('includes/footer.php'); ?>
