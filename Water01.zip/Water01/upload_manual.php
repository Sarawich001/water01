<?php
session_start();
include 'connection.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $file = $_FILES['manual'];

    if ($file['error'] === 0) {
        $upload_dir = "uploads/";
        // สร้างโฟลเดอร์ uploads/ ไว้ในโฟลเดอร์โปรเจกต์
        $file_name = basename($file['name']);
        $file_path = $upload_dir . $file_name;

        if (move_uploaded_file($file['tmp_name'], $file_path)) {
            // บันทึกลงฐานข้อมูล
            $sql = "INSERT INTO files (file_name, file_path) VALUES ('$file_name', '$file_path')";
            $con->query($sql);
            $_SESSION['success'] = "อัปโหลดคู่มือสำเร็จ!";
        } else {
            $_SESSION['failure'] = "เกิดข้อผิดพลาดในการอัปโหลดไฟล์";
        }
    } else {
        $_SESSION['failure'] = "กรุณาเลือกไฟล์";
    }

    header("Location: dashboard.php"); // กลับไปหน้า Dashboard หรือหน้าอื่นที่ต้องการ
    exit();
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>อัปโหลดคู่มือการใช้งาน</title>
</head>
<body>
    <h1>อัปโหลดคู่มือการใช้งาน</h1>
    <?php
    if (isset($_SESSION['success'])) {
        echo "<p style='color:green;'>{$_SESSION['success']}</p>";
        unset($_SESSION['success']);
    }
    if (isset($_SESSION['failure'])) {
        echo "<p style='color:red;'>{$_SESSION['failure']}</p>";
        unset($_SESSION['failure']);
    }
    ?>
    <form method="POST" enctype="multipart/form-data">
        <label>เลือกไฟล์คู่มือ (PDF, DOC, ฯลฯ):</label>
        <input type="file" name="manual" required>
        <button type="submit">อัปโหลด</button>
    </form>
</body>
</html>
