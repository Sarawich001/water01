<?php
session_start();

// ตรวจสอบการล็อกอิน
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

// เชื่อมต่อฐานข้อมูล
include 'connection.php';

// ดึงข้อมูลผู้ใช้จากฐานข้อมูล
$user_id = $_SESSION['user_id'];
$stmt = $con->prepare("SELECT * FROM admin WHERE id = ?");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();
$user = $result->fetch_assoc();
$stmt->close();

// ป้องกัน XSS
function sanitize($data) {
    return htmlspecialchars($data, ENT_QUOTES, 'UTF-8');
}

// จัดการการอัพเดตโปรไฟล์
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_profile'])) {
    $username = trim($_POST['username']);
    $email = trim($_POST['email']);
    $current_password = $_POST['current_password'];
    $new_password = $_POST['new_password'];
    $confirm_password = $_POST['confirm_password'];
    
    $error = false;
    $messages = [];
    
    // ตรวจสอบข้อมูล
    if (empty($username)) {
        $error = true;
        $messages[] = "กรุณากรอกชื่อผู้ใช้";
    }
    
    if (empty($email) || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = true;
        $messages[] = "กรุณากรอกอีเมลให้ถูกต้อง";
    }
    
    // ตรวจสอบการเปลี่ยนรหัสผ่าน
    if (!empty($current_password)) {
        // ตรวจสอบรหัสผ่านปัจจุบัน
        if (!password_verify($current_password, $user['password'])) {
            $error = true;
            $messages[] = "รหัสผ่านปัจจุบันไม่ถูกต้อง";
        } elseif ($new_password !== $confirm_password) {
            $error = true;
            $messages[] = "รหัสผ่านใหม่และยืนยันรหัสผ่านไม่ตรงกัน";
        } elseif (strlen($new_password) < 6) {
            $error = true;
            $messages[] = "รหัสผ่านใหม่ต้องมีความยาวอย่างน้อย 6 ตัวอักษร";
        }
    }
    
    // ถ้าไม่มีข้อผิดพลาด ให้อัพเดตข้อมูล
    if (!$error) {
        // เริ่มการอัพเดตข้อมูล
        if (!empty($current_password) && !empty($new_password)) {
            // อัพเดตทั้งข้อมูลและรหัสผ่าน
            $hashed_password = password_hash($new_password, PASSWORD_DEFAULT);
            $update_stmt = $con->prepare("UPDATE admin SET username = ?, email = ?, password = ? WHERE id = ?");
            $update_stmt->bind_param("sssi", $username, $email, $hashed_password, $user_id);
        } else {
            // อัพเดตเฉพาะข้อมูลโปรไฟล์
            $update_stmt = $con->prepare("UPDATE admin SET username = ?, email = ? WHERE id = ?");
            $update_stmt->bind_param("ssi", $username, $email, $user_id);
        }
        
        if ($update_stmt->execute()) {
            $_SESSION['username'] = $username;
            $_SESSION['email'] = $email;
            $success_message = "อัพเดตข้อมูลเรียบร้อยแล้ว";
            
            // อัพเดตข้อมูลผู้ใช้หลังจากอัพเดตในฐานข้อมูล
            $stmt = $con->prepare("SELECT * FROM admin WHERE id = ?");
            $stmt->bind_param("i", $user_id);
            $stmt->execute();
            $result = $stmt->get_result();
            $user = $result->fetch_assoc();
            $stmt->close();
        } else {
            $error = true;
            $messages[] = "เกิดข้อผิดพลาดในการอัพเดตข้อมูล: " . $con->error;
        }
        
        $update_stmt->close();
    }
    
    // จัดการอัพโหลดรูปภาพ
    if (isset($_FILES['profile_image']) && $_FILES['profile_image']['error'] == 0) {
        $allowed = ['jpg', 'jpeg', 'png', 'gif'];
        $filename = $_FILES['profile_image']['name'];
        $filetype = pathinfo($filename, PATHINFO_EXTENSION);
        
        // ตรวจสอบประเภทไฟล์
        if (in_array(strtolower($filetype), $allowed)) {
            // สร้างโฟลเดอร์เก็บรูปถ้ายังไม่มี
            $upload_dir = 'uploads/profiles/';
            if (!file_exists($upload_dir)) {
                mkdir($upload_dir, 0777, true);
            }
            
            // สร้างชื่อไฟล์ใหม่เพื่อป้องกันการซ้ำกัน
            $new_filename = 'profile_' . $user_id . '_' . time() . '.' . $filetype;
            $upload_path = $upload_dir . $new_filename;
            
            // อัพโหลดไฟล์
            if (move_uploaded_file($_FILES['profile_image']['tmp_name'], $upload_path)) {
                // บันทึกที่อยู่รูปภาพในฐานข้อมูล
                $img_stmt = $con->prepare("UPDATE admin SET profile_image = ? WHERE id = ?");
                $img_stmt->bind_param("si", $upload_path, $user_id);
                
                if ($img_stmt->execute()) {
                    $success_message = "อัพเดตข้อมูลและรูปโปรไฟล์เรียบร้อยแล้ว";
                    
                    // อัพเดตข้อมูลผู้ใช้ใหม่
                    $stmt = $con->prepare("SELECT * FROM admin WHERE id = ?");
                    $stmt->bind_param("i", $user_id);
                    $stmt->execute();
                    $result = $stmt->get_result();
                    $user = $result->fetch_assoc();
                    $stmt->close();
                } else {
                    $error = true;
                    $messages[] = "เกิดข้อผิดพลาดในการบันทึกข้อมูลรูปภาพ: " . $con->error;
                }
                
                $img_stmt->close();
            } else {
                $error = true;
                $messages[] = "เกิดข้อผิดพลาดในการอัพโหลดรูปภาพ";
            }
        } else {
            $error = true;
            $messages[] = "อนุญาตให้อัพโหลดเฉพาะไฟล์รูปภาพ (JPG, JPEG, PNG, GIF)";
        }
    }
}

// ปิดการเชื่อมต่อกับฐานข้อมูล
$con->close();
?>
<!DOCTYPE html>
<html lang="th">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>โปรไฟล์ของฉัน</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <!-- ฟอนต์ Kanit -->
    <link href="https://fonts.googleapis.com/css2?family=Kanit:wght@300;400;500&display=swap" rel="stylesheet">
    <style>
        body {
            font-family: 'Kanit', sans-serif;
            background: #f1f1f1;
            padding-top: 20px;
            padding-bottom: 20px;
        }
        .profile-card {
            background: #ffffff;
            padding: 2rem;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            margin-top: 2rem;
        }
        .profile-header {
            margin-bottom: 1.5rem;
        }
        .nav-links a {
            text-decoration: none;
        }
        .profile-image-container {
            position: relative;
            width: 150px;
            height: 150px;
            margin: 0 auto 20px;
        }
        .profile-image {
            width: 100%;
            height: 100%;
            border-radius: 50%;
            object-fit: cover;
            border: 3px solid #e1e1e1;
        }
        .profile-image-placeholder {
            width: 100%;
            height: 100%;
            border-radius: 50%;
            background-color: #e9ecef;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 3rem;
            color: #6c757d;
            border: 3px solid #e1e1e1;
        }
        .edit-image-btn {
            position: absolute;
            bottom: 0;
            right: 0;
            background: #007bff;
            color: white;
            border-radius: 50%;
            width: 40px;
            height: 40px;
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            border: 2px solid white;
        }
        .tab-content {
            padding-top: 20px;
        }
        .form-group {
            margin-bottom: 1rem;
        }
        .alert-container {
            margin-bottom: 20px;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="profile-card">
            <div class="profile-header text-center">
                <h2><i class="fas fa-user-circle"></i> โปรไฟล์ของฉัน</h2>
            </div>
            
            <!-- แสดงข้อความแจ้งเตือน -->
            <div class="alert-container">
                <?php if (isset($error) && $error): ?>
                    <div class="alert alert-danger">
                        <ul class="mb-0">
                            <?php foreach ($messages as $message): ?>
                                <li><?php echo $message; ?></li>
                            <?php endforeach; ?>
                        </ul>
                    </div>
                <?php endif; ?>
                
                <?php if (isset($success_message)): ?>
                    <div class="alert alert-success">
                        <?php echo $success_message; ?>
                    </div>
                <?php endif; ?>
            </div>
            
            <!-- แท็บเมนู -->
            <ul class="nav nav-tabs" id="profileTabs" role="tablist">
                <li class="nav-item" role="presentation">
                    <button class="nav-link active" id="info-tab" data-bs-toggle="tab" data-bs-target="#info" type="button" role="tab" aria-controls="info" aria-selected="true">
                        <i class="fas fa-info-circle"></i> ข้อมูลโปรไฟล์
                    </button>
                </li>
                <li class="nav-item" role="presentation">
                    <button class="nav-link" id="edit-tab" data-bs-toggle="tab" data-bs-target="#edit" type="button" role="tab" aria-controls="edit" aria-selected="false">
                        <i class="fas fa-edit"></i> แก้ไขโปรไฟล์
                    </button>
                </li>
            </ul>
            
            <!-- เนื้อหาแท็บ -->
            <div class="tab-content" id="profileTabsContent">
                <!-- แท็บข้อมูลโปรไฟล์ -->
                <div class="tab-pane fade show active" id="info" role="tabpanel" aria-labelledby="info-tab">
                    <div class="text-center mb-4">
                        <div class="profile-image-container">
                            <?php if (isset($user['profile_image']) && !empty($user['profile_image']) && file_exists($user['profile_image'])): ?>
                                <img src="<?php echo sanitize($user['profile_image']); ?>" alt="รูปโปรไฟล์" class="profile-image">
                            <?php else: ?>
                                <div class="profile-image-placeholder">
                                    <i class="fas fa-user"></i>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                    
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <div class="card">
                                <div class="card-body">
                                    <h5 class="card-title"><i class="fas fa-user"></i> ชื่อผู้ใช้</h5>
                                    <p class="card-text"><?php echo sanitize($user['username']); ?></p>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6 mb-3">
                            <div class="card">
                                <div class="card-body">
                                    <h5 class="card-title"><i class="fas fa-envelope"></i> อีเมล</h5>
                                    <p class="card-text"><?php echo sanitize($user['email']); ?></p>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="d-flex justify-content-center gap-3 mt-4">
                        <a href="index.php" class="btn btn-secondary">
                            <i class="fas fa-home"></i> หน้าหลัก
                        </a>
                        <a href="logout.php" class="btn btn-danger">
                            <i class="fas fa-sign-out-alt"></i> ออกจากระบบ
                        </a>
                    </div>
                </div>
                
                <!-- แท็บแก้ไขโปรไฟล์ -->
                <div class="tab-pane fade" id="edit" role="tabpanel" aria-labelledby="edit-tab">
                    <form action="" method="POST" enctype="multipart/form-data">
                        <div class="text-center mb-4">
                            <div class="profile-image-container">
                                <?php if (isset($user['profile_image']) && !empty($user['profile_image']) && file_exists($user['profile_image'])): ?>
                                    <img src="<?php echo sanitize($user['profile_image']); ?>" alt="รูปโปรไฟล์" class="profile-image" id="profile-image-preview">
                                <?php else: ?>
                                    <div class="profile-image-placeholder" id="profile-image-placeholder">
                                        <i class="fas fa-user"></i>
                                    </div>
                                    <img src="" alt="รูปโปรไฟล์" class="profile-image" id="profile-image-preview" style="display: none;">
                                <?php endif; ?>
                                <label for="profile_image" class="edit-image-btn">
                                    <i class="fas fa-camera"></i>
                                </label>
                                <input type="file" id="profile_image" name="profile_image" accept="image/*" style="display: none;">
                            </div>
                        </div>
                        
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <div class="form-group">
                                    <label for="username"><i class="fas fa-user"></i> ชื่อผู้ใช้</label>
                                    <input type="text" class="form-control" id="username" name="username" value="<?php echo sanitize($user['username']); ?>" required>
                                </div>
                            </div>
                            <div class="col-md-6 mb-3">
                                <div class="form-group">
                                    <label for="email"><i class="fas fa-envelope"></i> อีเมล</label>
                                    <input type="email" class="form-control" id="email" name="email" value="<?php echo sanitize($user['email']); ?>" required>
                                </div>
                            </div>
                        </div>
                        
                        <div class="mb-3">
                            <div class="form-check">
                                <input class="form-check-input" type="checkbox" id="change_password" name="change_password">
                                <label class="form-check-label" for="change_password">
                                    <i class="fas fa-lock"></i> เปลี่ยนรหัสผ่าน
                                </label>
                            </div>
                        </div>
                        
                        <div id="password_fields" style="display: none;">
                            <div class="row">
                                <div class="col-md-12 mb-3">
                                    <div class="form-group">
                                        <label for="current_password"><i class="fas fa-key"></i> รหัสผ่านปัจจุบัน</label>
                                        <input type="password" class="form-control" id="current_password" name="current_password">
                                    </div>
                                </div>
                                <div class="col-md-6 mb-3">
                                    <div class="form-group">
                                        <label for="new_password"><i class="fas fa-lock"></i> รหัสผ่านใหม่</label>
                                        <input type="password" class="form-control" id="new_password" name="new_password">
                                        <small class="form-text text-muted">รหัสผ่านต้องมีความยาวอย่างน้อย 6 ตัวอักษร</small>
                                    </div>
                                </div>
                                <div class="col-md-6 mb-3">
                                    <div class="form-group">
                                        <label for="confirm_password"><i class="fas fa-lock"></i> ยืนยันรหัสผ่านใหม่</label>
                                        <input type="password" class="form-control" id="confirm_password" name="confirm_password">
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <div class="d-flex justify-content-center mt-4">
                            <button type="submit" name="update_profile" class="btn btn-primary">
                                <i class="fas fa-save"></i> บันทึกข้อมูล
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <!-- Bootstrap JS Bundle -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    
    <script>
        // สคริปต์สำหรับแสดงตัวอย่างรูปภาพที่เลือก
        document.getElementById('profile_image').addEventListener('change', function(e) {
            const file = e.target.files[0];
            if (file) {
                const reader = new FileReader();
                reader.onload = function(e) {
                    const preview = document.getElementById('profile-image-preview');
                    const placeholder = document.getElementById('profile-image-placeholder');
                    
                    preview.src = e.target.result;
                    preview.style.display = 'block';
                    
                    if (placeholder) {
                        placeholder.style.display = 'none';
                    }
                }
                reader.readAsDataURL(file);
            }
        });
        
        // สคริปต์สำหรับแสดง/ซ่อนฟิลด์รหัสผ่าน
        document.getElementById('change_password').addEventListener('change', function() {
            document.getElementById('password_fields').style.display = this.checked ? 'block' : 'none';
            
            // ล้างค่าฟิลด์รหัสผ่านเมื่อยกเลิกการเปลี่ยนรหัสผ่าน
            if (!this.checked) {
                document.getElementById('current_password').value = '';
                document.getElementById('new_password').value = '';
                document.getElementById('confirm_password').value = '';
            } else {
                // ทำให้ฟิลด์รหัสผ่านปัจจุบันเป็น required เมื่อต้องการเปลี่ยนรหัสผ่าน
                document.getElementById('current_password').required = true;
                document.getElementById('new_password').required = true;
                document.getElementById('confirm_password').required = true;
            }
        });
    </script>
</body>
</html>