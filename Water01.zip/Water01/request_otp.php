<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// ใช้ require โดยตรงแทนการใช้ Composer
// สร้างโฟลเดอร์ PHPMailer และวางไฟล์ในนั้น
// ถ้าไฟล์อยู่ในที่อื่น ให้ปรับ path ตามความเหมาะสม
// ถ้าไม่มีไฟล์ให้ดาวน์โหลดจาก https://github.com/PHPMailer/PHPMailer/

// ตรวจสอบว่าโฟลเดอร์มีอยู่หรือไม่ และใช้ try...catch เพื่อจับข้อผิดพลาด
$phpmailer_loaded = false;
$phpmailer_error = "";

<?php
// ใช้ namespace ที่ด้านบนของไฟล์
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

try {
    // ตรวจสอบว่าไฟล์ของ PHPMailer มีอยู่หรือไม่
    if (file_exists('PHPMailer/src/Exception.php') && 
        file_exists('PHPMailer/src/PHPMailer.php') && 
        file_exists('PHPMailer/src/SMTP.php')) {
        
        // โหลดไฟล์ของ PHPMailer
        require 'PHPMailer/src/Exception.php';
        require 'PHPMailer/src/PHPMailer.php';
        require 'PHPMailer/src/SMTP.php';
        
        // ตั้งค่าตัวแปรเพื่อระบุว่า PHPMailer โหลดสำเร็จ
        $phpmailer_loaded = true;
    } else {
        // แจ้งเตือนหากไม่พบไฟล์
        $phpmailer_error = "ไม่พบไฟล์ของ PHPMailer กรุณาดาวน์โหลดและติดตั้งก่อน";
    }
} catch (Exception $e) {
    // ดักจับข้อผิดพลาดและแสดงข้อความ
    $phpmailer_error = "เกิดข้อผิดพลาดในการโหลด PHPMailer: " . $e->getMessage();
}
?>
// เริ่ม session ถ้ายังไม่ได้เริ่ม
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

// ตัวแปรสำหรับเก็บข้อความสถานะ
$status_message = "";
$status_type = ""; // success หรือ error

/**
 * ฟังก์ชันสำหรับสร้าง OTP
 * @param int $length ความยาวของ OTP
 * @return string
 */
function generateOTP($length = 6) {
    // สร้าง OTP แบบตัวเลขเท่านั้น
    $otp = "";
    for ($i = 0; $i < $length; $i++) {
        $otp .= rand(0, 9);
    }
    return $otp;
}

/**
 * ฟังก์ชันสำหรับส่ง OTP ทางอีเมล
 * @param string $email อีเมลของผู้รับ
 * @param string $otp รหัส OTP
 * @return bool สถานะการส่ง
 */
function sendOTPEmail($email, $otp) {
    global $phpmailer_loaded;
    
    if (!$phpmailer_loaded) {
        return false;
    }
    
    // สร้างอินสแตนซ์ของ PHPMailer
    $mail = new PHPMailer(true);

    try {
        // ตั้งค่า SMTP สำหรับการส่งเมล
        $mail->isSMTP();
        $mail->Host       = 'smtp.gmail.com';     // SMTP server (เปลี่ยนเป็น Gmail)
        $mail->SMTPAuth   = true;
        $mail->Username   = 'your_email@gmail.com'; // เปลี่ยนเป็นอีเมล Gmail ของคุณ
        $mail->Password   = 'your_app_password';    // รหัสแอป (ไม่ใช่รหัสผ่านปกติ)
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
        $mail->Port       = 3306;

        // ตั้งค่าผู้ส่งและผู้รับ
        $mail->setFrom('sarawich30@gmail.com', 'ระบบยืนยันตัวตน');
        $mail->addAddress($email);

        // ตั้งค่าเนื้อหาอีเมล
        $mail->isHTML(true);
        $mail->Subject = 'รหัส OTP สำหรับการยืนยันตัวตน';
        
        // เนื้อหาอีเมลแบบ HTML
        $mail->Body = "
            <html>
            <head>
                <style>
                    body { font-family: Arial, sans-serif; }
                    .container { max-width: 600px; margin: 0 auto; padding: 20px; }
                    .otp-code { font-size: 24px; font-weight: bold; color: #333; text-align: center; 
                               padding: 10px; background-color: #f0f0f0; border-radius: 5px; }
                    .info { margin-top: 20px; color: #666; }
                </style>
            </head>
            <body>
                <div class='container'>
                    <h2>รหัส OTP สำหรับการยืนยันตัวตน</h2>
                    <p>รหัส OTP ของคุณคือ:</p>
                    <div class='otp-code'>{$otp}</div>
                    <div class='info'>
                        <p>รหัสนี้จะหมดอายุภายใน 5 นาที</p>
                        <p>หากคุณไม่ได้ร้องขอรหัสนี้ กรุณาละเว้นอีเมลฉบับนี้</p>
                    </div>
                </div>
            </body>
            </html>
        ";
        
        // เนื้อหาอีเมลแบบข้อความธรรมดา
        $mail->AltBody = "รหัส OTP ของคุณคือ: {$otp}\n\nรหัสนี้จะหมดอายุภายใน 5 นาที\n\nหากคุณไม่ได้ร้องขอรหัสนี้ กรุณาละเว้นอีเมลฉบับนี้";

        // ส่งอีเมล
        $mail->send();
        return true;
    } catch (Exception $e) {
        error_log("ไม่สามารถส่งอีเมล OTP ได้: {$mail->ErrorInfo}");
        return false;
    }
}

/**
 * ฟังก์ชันสำหรับตรวจสอบความถูกต้องของ OTP
 * @param string $userOTP รหัส OTP ที่ผู้ใช้กรอก
 * @return bool สถานะการตรวจสอบ
 */
function verifyOTP($userOTP) {
    // ตรวจสอบว่ามี session OTP หรือไม่
    if (!isset($_SESSION['otp']) || !isset($_SESSION['otp_time'])) {
        return false;
    }
    
    // ตรวจสอบว่า OTP หมดอายุหรือไม่ (5 นาที)
    if (time() - $_SESSION['otp_time'] > 300) {
        // OTP หมดอายุแล้ว ลบออกจาก session
        unset($_SESSION['otp']);
        unset($_SESSION['otp_time']);
        unset($_SESSION['otp_email']);
        return false;
    }
    
    // ตรวจสอบความถูกต้องของ OTP
    if ($_SESSION['otp'] === $userOTP) {
        // OTP ถูกต้อง ลบออกจาก session เพื่อไม่ให้ใช้ซ้ำ
        unset($_SESSION['otp']);
        unset($_SESSION['otp_time']);
        // คุณอาจเก็บ $_SESSION['otp_email'] ไว้เพื่อใช้ในขั้นตอนต่อไป
        return true;
    }
    
    return false;
}

// จัดการ form submissions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // ถ้ามีการส่งอีเมลเพื่อขอ OTP
    if (isset($_POST['email']) && !isset($_POST['verify_otp'])) {
        $email = filter_var($_POST['email'], FILTER_VALIDATE_EMAIL);
        
        if ($email) {
            // สร้าง OTP
            $otp = generateOTP(6);
            
            // บันทึก OTP ลงใน session
            $_SESSION['otp'] = $otp;
            $_SESSION['otp_time'] = time();
            $_SESSION['otp_email'] = $email;
            
            // ถ้าโหลด PHPMailer สำเร็จ ให้ส่ง OTP
            if ($phpmailer_loaded) {
                if (sendOTPEmail($email, $otp)) {
                    $status_message = "ระบบได้ส่งรหัส OTP ไปยังอีเมล {$email} แล้ว กรุณาตรวจสอบกล่องจดหมายของคุณ";
                    $status_type = "success";
                    
                    // กำหนดให้แสดงฟอร์มยืนยัน OTP
                    $_SESSION['show_verify_form'] = true;
                } else {
                    $status_message = "เกิดข้อผิดพลาดในการส่งอีเมล กรุณาลองอีกครั้งภายหลัง";
                    $status_type = "error";
                }
            } else {
                // ถ้ายังไม่ได้ติดตั้ง PHPMailer ให้แสดง OTP ที่หน้าจอสำหรับการทดสอบ
                $status_message = "โหมดทดสอบ: รหัส OTP ของคุณคือ {$otp} (รหัสนี้จะหมดอายุภายใน 5 นาที)";
                $status_type = "success";
                
                // กำหนดให้แสดงฟอร์มยืนยัน OTP
                $_SESSION['show_verify_form'] = true;
            }
        } else {
            $status_message = "กรุณากรอกอีเมลที่ถูกต้อง";
            $status_type = "error";
        }
    }
    
    // ถ้ามีการส่ง OTP เพื่อยืนยัน
    if (isset($_POST['verify_otp'])) {
        $userOTP = $_POST['verify_otp'];
        
        if (verifyOTP($userOTP)) {
            $status_message = "ยืนยันตัวตนสำเร็จ!";
            $status_type = "success";
            
            // ล้างการแสดงฟอร์มยืนยัน
            unset($_SESSION['show_verify_form']);
            
            // สามารถ redirect ไปหน้าอื่นได้ที่นี่
            // header("Location: success_page.php");
            // exit;
        } else {
            $status_message = "รหัส OTP ไม่ถูกต้องหรือหมดอายุแล้ว กรุณาลองอีกครั้ง";
            $status_type = "error";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="th">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ระบบยืนยันตัวตนด้วย OTP</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            line-height: 1.6;
            margin: 0;
            padding: 20px;
            background-color: #f5f5f5;
        }
        .container {
            max-width: 500px;
            margin: 50px auto;
            padding: 20px;
            background: white;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
        }
        h1 {
            text-align: center;
            color: #333;
        }
        form {
            margin-top: 20px;
        }
        label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
        }
        input[type="email"],
        input[type="text"] {
            width: 100%;
            padding: 10px;
            margin-bottom: 20px;
            border: 1px solid #ddd;
            border-radius: 4px;
            box-sizing: border-box;
        }
        button {
            display: block;
            width: 100%;
            padding: 10px;
            background-color: #4CAF50;
            color: white;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 16px;
        }
        button:hover {
            background-color: #45a049;
        }
        .message {
            margin: 20px 0;
            padding: 15px;
            border-radius: 4px;
        }
        .success {
            background-color: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }
        .error {
            background-color: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }
        .warning {
            background-color: #fff3cd;
            color: #856404;
            border: 1px solid #ffeeba;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>ระบบยืนยันตัวตนด้วย OTP</h1>
        
        <?php if (!empty($phpmailer_error)): ?>
        <div class="message warning">
            <strong>คำเตือน:</strong> <?php echo $phpmailer_error; ?><br>
            <small>สามารถทดสอบระบบได้โดย OTP จะแสดงบนหน้าเว็บแทนการส่งอีเมล</small>
        </div>
        <?php endif; ?>
        
        <?php if (!empty($status_message)): ?>
        <div class="message <?php echo $status_type; ?>">
            <?php echo $status_message; ?>
        </div>
        <?php endif; ?>
        
        <?php if (!isset($_SESSION['show_verify_form'])): ?>
        <!-- ฟอร์มส่งอีเมลขอ OTP -->
        <form method="post" action="">
            <label for="email">อีเมลของคุณ:</label>
            <input type="email" id="email" name="email" required placeholder="example@domain.com">
            <button type="submit">ส่ง OTP</button>
        </form>
        <?php else: ?>
        <!-- ฟอร์มยืนยัน OTP -->
        <form method="post" action="">
            <label for="verify_otp">กรอกรหัส OTP ที่ได้รับทางอีเมล:</label>
            <input type="text" id="verify_otp" name="verify_otp" required placeholder="กรอกรหัส OTP 6 หลัก" maxlength="6" pattern="[0-9]{6}">
            <button type="submit">ยืนยันรหัส OTP</button>
        </form>
        <?php endif; ?>
    </div>
</body>
</html>