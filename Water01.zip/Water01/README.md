# Water-Management-System
Website Live here >> http://watersupplymanagement.equitableitservices.com/
## Instalation
- Move this Project Folder to c://xampp/htdocs or you can using PHP SERVER Extention in VS code  to Run this project
- Import the database water-managment.sql to your phpmyadmin with the db name as <i>water-managment</i> Or you can chage the Db name in conection.php
- Done, Now the Project is Runnable 
## Features 
- Hashed/Protected credentials
- Managed Tracking of products and stocks depanding on vendors and customer 
- Used Foregin Key's in Database 
- Message Customer the bill with one click on Whatsapp

## Login Page 
![image](https://user-images.githubusercontent.com/45972990/158062226-1e58f9ef-6921-45b2-936c-812266cfb2a2.png)
## index Page
![image](https://user-images.githubusercontent.com/45972990/158062271-4e0c0909-23cf-46f5-8f4c-8fe4139f1611.png)
## Products Page
![image](https://user-images.githubusercontent.com/45972990/158062289-9d13acb4-6456-4cb9-955a-ebffb5a26d6d.png)
## Vendors Page
![image](https://user-images.githubusercontent.com/45972990/158062346-55b26748-c1ce-4a6b-9a56-3c7c5d28bc2e.png)
## Customer Page
![image](https://user-images.githubusercontent.com/45972990/158062380-e6e708b8-c8a1-4da9-b472-8746d98eb916.png)
## Add Customer/Products/Vendors Page
![image](https://user-images.githubusercontent.com/45972990/158062462-32658942-5c89-4a87-b33d-e686e3ab9f70.png)

## Placed Order pages
![image](https://user-images.githubusercontent.com/45972990/158062405-b2c3943d-3010-4c40-97a3-21825e9d1dfe.png)
## Bill Page for Placed Orders
![image](https://user-images.githubusercontent.com/45972990/158062495-c4e844be-1fe3-4357-9570-b434048365d9.png)
## Whatsapp Automatic Bill message for customer
![image](https://user-images.githubusercontent.com/45972990/158063687-609fc1eb-cf7f-4cba-87e7-ce3f35d315c4.png)




